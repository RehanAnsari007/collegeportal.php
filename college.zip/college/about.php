<?php include('header.php');?>
<!-- banner -->
  <div class="courses_banner">
  	<div class="container">
  		<h3>About</h3>
  		<p class="description">
             Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer lorem quam, adipiscing condimentum tristique vel, eleifend sed turpis. Pellentesque cursus arcu id magna euismod in elementum purus molestie.
        </p>
        <div class="breadcrumb1">
            <ul>
                <li class="icon6"><a href="index.php">Home</a></li>
                <li class="current-page">About</li>
            </ul>
        </div>
  	</div>
  </div>
    <!-- //banner -->
	<div class="courses_box1">
	   <div class="container">
	   	  <div class="col-md-6 about_left">
	   	  	<h1>Welcome</h1>
	   	  	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
	   	    <ul class="about_links">
                <li><a href="#">Ut wisi enim ad minim veniam, quis nostrud</a></li>
                <li><a href="#">Exerci tation ullamcorper suscipit lobortis nisl aliquip</a></li>
                <li><a href="#">Duis autem vel eum iriure dolor</a></li>
            </ul>
            <a href="#" class="radial_but">Read More</a>
          </div>
	   	  <div class="col-md-6">
	   	  	<img src="images/event.jpg" class="img-responsive" alt=""/>
	   	  </div>
	   	  <div class="clearfix"> </div>
	   </div>
	</div>
	<div class="advantage">
		<h3>Why Us</h3>
		<div class="container">
			<div class="col-md-4 box_1">
  			<div class="list styled custom-list custom-list1">
				<ul>
					<li><span class="dropcap">1.</span>  
					   <div class="item_content">
						<h5><a href="#">nunc nobis videntur parum</a></h5> 
						<p> anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur paru.</p>
						<p class="m_1">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock</p>
					   </div>
					</li>
			    </ul>
			</div>
	     </div>
	     <div class="col-md-4 box_1">
  			<div class="list styled custom-list custom-list1">
				<ul>
					<li><span class="dropcap">2.</span>  
					   <div class="item_content">
						<h5><a href="#">nunc nobis videntur parum</a></h5> 
						<p> anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur paru.</p>
						<p class="m_1">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock</p>
					   </div>
					</li>
			    </ul>
			</div>
	     </div>
	     <div class="col-md-4 box_1">
  			<div class="list styled custom-list custom-list1">
				<ul>
					<li><span class="dropcap">3.</span>  
					   <div class="item_content">
						<h5><a href="#">nunc nobis videntur parum</a></h5> 
						<p> anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur paru.</p>
						<p class="m_1">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock</p>
					   </div>
					</li>
			    </ul>
			</div>
	     </div>
	     <div class="clearfix"> </div>
		</div>
	</div>
   <?php include('footer.php');?>