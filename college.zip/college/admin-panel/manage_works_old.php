<?php 
include('header2.php');
$id=$_GET['id'];
$select =mysql_query("select * from works where id='1'");
$res=mysql_fetch_array($select);

if(isset($_POST['update'])){
$content=mysql_real_escape_string($_POST['content']);


$insert=mysql_query("update works set content='$content'  where id='1'");
if($insert){
?>
<script>alert('Updated ! ');
window.location.href='index2.php?list=true';
</script>
<?php
}
}
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

<div class="content">
<div class="title"><br>
<h4 class="red" style="margin:10px;">Update How it works</h4><hr>
</div>
<form name="frm" action="" method="post" enctype="multipart/form-data">
<script src="ckeditor/ckeditor.js"></script>
        <script src="ckeditor/config.js"></script>

<b> Content :</b> <textarea  id="editor1"  name="content" ><?php echo $res['content'];?></textarea><br><br>
 <script>
               CKEDITOR.replace( 'editor1' );
            </script>

<input class="black" type="submit" name="update" value="Update How it Works"><hr>
</form>
<?php // echo $urll;?>
</div>
</div>
</div>

<?php include('footer.php');?>
