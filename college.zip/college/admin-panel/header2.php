<?php session_start();

if(!isset($_SESSION['email']))
{ 
$aemail = $_SESSION['email'];
?>
<script>document.location='login.php';</script>
<?php
}
include('connection.php');
?>
<?php include('connection.php');?>
<?php  $selectr= mysql_query("select * from admin where email='".$_SESSION['email']."'");
$resd=mysql_fetch_array($selectr);

?>
<?php 
//dynamic host url
$url= 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$dir_url=$_SERVER['REQUEST_URI'];
$host=$_SERVER['HTTP_HOST']; 
$ex= explode("/",$url);
$k = $ex;
$sliced = array_slice($k, 0, -1); // array ( "1", "2" )
$urll = implode("/", $sliced);
//echo $urll;
//dynamic host url 
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Artist</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
 <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
 


 <!-- iCheck -->
  
  <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="plugins/morris/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
<style>
.title{font-size:25px;color:purple;}

hr {
    -moz-border-bottom-colors: none;
    -moz-border-left-colors: none;
    -moz-border-right-colors: none;
    -moz-border-top-colors: none;
    border-color: #000000 -moz-use-text-color -moz-use-text-color;
    border-image: none;
    border-style: solid none none;
    border-width: 1px 0 0;
    margin-bottom: 20px;
    margin-top: 20px;
}


</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script>
(function(document) {
	'use strict';

	var LightTableFilter = (function(Arr) {

		var _input;

		function _onInputEvent(e) {
			_input = e.target;
			var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>
<!-- start color box-->
<link rel="stylesheet" href="colorbox.css" />
		
		<script src="jquery.colorbox.js"></script>
		<script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				
				
				$("#iframe").colorbox({iframe:true, width:"80%", height:"80%"});
				
				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
<script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				
				
				$("#iframe1").colorbox({iframe:true, width:"80%", height:"80%"});
				
				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
		<script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				
				
				$("#iframe2").colorbox({iframe:true, width:"80%", height:"80%"});
				
				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
<script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				
				
				$("#iframe3").colorbox({iframe:true, width:"80%", height:"80%"});
				
				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
<script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				
				
				$("#iframe4").colorbox({iframe:true, width:"80%", height:"80%"});
				
				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
<script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
				
				
				$("#iframe5").colorbox({iframe:true, width:"80%", height:"80%"});
				
				//Example of preserving a JavaScript event for inline calls.
				$("#click").click(function(){ 
					$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
					return false;
				});
			});
		</script>
		<!---colorbox ends-->

</head>
<!-- ADD THE CLASS fixed TO GET A FIXED HEADER AND SIDEBAR LAYOUT -->
<!-- the fixed layout is not compatible with sidebar-mini -->
<body class="hold-transition skin-blue fixed sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <header class="main-header" style="">
    <!-- Logo -->
    <a href="index2.php" class="logo" style="padding-top:5px;">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b> Artist</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b></b> <img src="images/logo2.png" class="img-responsive"></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
		<!-- upload-->
		<li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
            Upload  <i class="fa fa-caret-down"> </i>
            
            </a>
            <ul class="dropdown-menu">
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li> <a href="submit-photos.php">  <i class="fa fa-cog text-aqua"></i> Upload  </a> </li>
               <li> <a href="draft.php">  <i class="fa fa-cog text-aqua"></i> Submit  </a> </li>
             <li> <a href="#">  <i class="fa fa-cog text-aqua"></i> Pending  </a> </li>
             <li> <a href="#">  <i class="fa fa-cog text-aqua"></i> Reviewed  </a> </li>
             <li> <a href="#">  <i class="fa fa-cog text-aqua"></i> File Manager  </a> </li>
             <li> <a href="#">  <i class="fa fa-cog text-aqua"></i> Releases  </a> </li>
              <li> <a href="#">  <i class="fa fa-cog text-aqua"></i> Keyword  </a> </li>
             
               
                 
                </ul>
              </li>
             
            </ul>
          </li>
		<!-- upload ends-->
		<!-- upload-->
		<li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
            Dashboard  <i class="fa fa-caret-down"> </i>
            
            </a>
            <ul class="dropdown-menu">
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li> <a href="index2.php">  <i class="fa fa-cog text-aqua"></i> Dashboard  </a> </li>
               <li> <a href="#">  <i class="fa fa-cog text-aqua"></i> My Portfolio  </a> </li>
             <li> <a href="#">  <i class="fa fa-cog text-aqua"></i> Promotion  </a> </li>
             <li> <a href="#">  <i class="fa fa-cog text-aqua"></i> Shoot Planning  </a> </li>
             
               
                 
                </ul>
              </li>
             
            </ul>
          </li>
		<!-- upload ends-->
		<!-- t1-->
		<li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">2</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 2 notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-aqua"></i> Notification 1
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-aqua"></i> Notification 2
                    </a>
                  </li>
                 
                </ul>
              </li>
              <li class="footer"><a href="#">View all</a></li>
            </ul>
          </li>
		<!-- t1 ends-->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" style="padding-top: 9px;padding-bottom: 9px;">
			  <span class="hidden-xs">
				  <?php if($resd['image']!=''){ $img = $resd['image']; echo "<img src='$img' style='width:30px;    display: inline;'>"; } else{ ?>  <img src="images/Male-Avatar.png" style='width:30px;'class="img-responsive" alt="User Image" >
        <?php } ?> 
				  Hello, <?php echo $resd['full_name'];?> <i class="fa fa-arrow-down"></i>
			  </span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header" style="height:auto;">
                  <p>
                  <?php echo $resd['full_name'];?>
                 </p>
              </li>
             
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="updateprofile2.php" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout2.php" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>

  <!-- =============================================== -->


  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar" style="overflow-y: scroll;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="">
       <a href="submit-photos.php">  <img src="images/upload.png" class="img-responsive" alt="User Image" ></a>
        
      </div>
      <!-- search form -->
     <!-- <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>-->
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
       <li class="treeview">
          <a href="index2.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span></i>
          </a>
        </li>
<li><a href="updateprofile2.php" ><i class="fa fa-user"></i> 	My Account  </a></li>

	<!-- earnings starts--->
		<li class="treeview menu-open" style="height: auto;">
          <a href="#">
            <i class="fa fa-cloud"></i> <span>Files</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="">
            <li><a href="submit-photos.php"><i class="fa fa-circle-o"></i> Upload</a></li>
            <li><a href="draft.php"><i class="fa fa-circle-o"></i> Submit</a></li>
            <li class="active"><a href="#"><i class="fa fa-circle-o"></i> Pending</a></li>
             <li class="active"><a href="#"><i class="fa fa-circle-o"></i> Reviewed</a></li>
             <li class="active"><a href="#"><i class="fa fa-circle-o"></i> File Manager</a></li>
             <li class="active"><a href="#"><i class="fa fa-circle-o"></i> Releases</a></li>
          </ul>
        </li>
		<!-- earnings end-->
		<!-- earnings starts--->
		<li class="treeview menu-open" style="height: auto;">
          <a href="#">
            <i class="fa fa-rupee"></i> <span>Earnings</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="">
            <li><a href="#"><i class="fa fa-circle-o"></i> Today</a></li>
            <li class="active"><a href="#"><i class="fa fa-circle-o"></i> This Month</a></li>
             <li class="active"><a href="#"><i class="fa fa-circle-o"></i> All Time</a></li>
          </ul>
        </li>
		<!-- earnings end-->
<li><a href="#all-photos.php" ><i class="fa fa-camera"></i> 	My Portfolio  </a></li>
<li><a href="#" ><i class="fa fa-events"></i> Promotions  </a></li>





 </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  