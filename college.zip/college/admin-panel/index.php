<?php include('connection.php'); ?>

<?php include('header.php'); ?>

 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!--  Content Header (Page header)  -->
    <section class="content-header">
<div class="content"><h1>Home</h1><hr>
<p>Welcome</p>
<hr>
<center>

</center>
</div>
</div>
</div>

<?php include('footer.php'); ?>
