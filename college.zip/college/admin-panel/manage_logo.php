<?php 
include('header2.php');
$id=$_GET['id'];
$select =mysql_query("select * from logo where id='1'");
$res=mysql_fetch_array($select);

if(isset($_POST['update'])){
if (is_uploaded_file($_FILES['image']['tmp_name'])) {
$imgg=basename($_FILES["image"]["name"]);
$tpathh=$_FILES["image"]["tmp_name"];
 $pathh="images/".$imgg;
move_uploaded_file($tpathh,$pathh);
}
else
{
$pathh=$resd['image'];
}

$insert=mysql_query("update logo set image='$pathh' where id='1'");
if($insert){
?>
<script>alert('Logo Updated ! ');
window.location.href='index2.php?list=true';
</script>
<?php
}
}
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

<div class="content">
<div class="title"><br>
<h4 class="red" style="margin:10px;">Update Logo</h4><hr>
</div>
<form name="frm" action="" method="post" enctype="multipart/form-data">

<br><b>Current Image :<b> <img src="<?php echo $res['image'];?>" ><br><br>
<b> Browse & Change Image (size should be 501x51 otherwise design will be damaged):</b> <input type="file" name="image" style="width:60%;"><br><br>

<input class="black" type="submit" name="update" value="Update Logo"><hr>
</form>
<?php // echo $urll;?>
</div>
</div>
</div>

<?php include('footer.php');?>
