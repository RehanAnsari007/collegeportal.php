<?php 

$ip = $_SERVER['REMOTE_ADDR'];
$query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
    if($query && $query['status'] == 'success')
    {
        echo 'Your City is ' . $query['city'];
        echo '<br />';
        echo 'Your State is ' . $query['region'];
        echo '<br />';
        echo 'Your Zipcode is ' . $query['zip'];
        echo '<br />';
        echo 'Your Coordinates are ' . $query['lat'] . ', ' . $query['lon'];
    }
    ?>
