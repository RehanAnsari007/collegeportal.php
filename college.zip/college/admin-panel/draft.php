<?php 
include('header2.php');
$id=$_SESSION['email'];
$select =mysql_query("select * from users where email='$id'");
$res=mysql_fetch_array($select);

if(isset($_POST['update'])){
$full_name=$_POST['full_name'];
$username=$_POST['username'];
$password=$_POST['password'];

if (is_uploaded_file($_FILES['image']['tmp_name'])) {
$imgg=basename($_FILES["image"]["name"]);
$tpathh=$_FILES["image"]["tmp_name"];
 $pathh="images/".$imgg;
move_uploaded_file($tpathh,$pathh);
}
else
{
$pathh=$resd['image'];
}

$insert=mysql_query("update users set full_name='$full_name',username='$username',password='$password',image='$pathh' where email='$id'");
if($insert){
?>
<script>alert('Profile Updated ! ');
window.location.href='updateprofile2.php?list=true';
</script>
<?php
}
}
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

<div class="content" style="background-color:#fff;">
<div class="title"><br>
<h4 class="red" style="margin:10px;">Not Yet Submitted</h4><hr>
</div>	
<?php 
$nycheck = mysql_query("select * from photos where email='".$_SESSION['email']."' AND type='draft'");
if(mysql_num_rows($nycheck)>0){
	while($res=mysql_fetch_array($nycheck)){
		?>
		<div class='col-md-2'><input type="checkbox" style="display:inline;">
		<center><img src='<?php echo $res['url'];?>' style='width:100px;height:100px;display:inline;'><br>
		<small>Date-added <br> <?php echo $res['date'];?></small>
		</center> 
		<br></div>
		<?php		
	}
	echo "<div class='clearfix'></div><button class='btn-primary'>Next</button>";
}
else{
	echo "<h3>There are no images in draft...!</h3>";
}
?>
<br><br><br><br><br><br><br><br><br><br><br><br>
</div>
</div>


<?php include('footer.php');?>
