<?php 
include('header2.php');
include('datatable.php');
//update
if(isset($_POST['update'])){

if (is_uploaded_file($_FILES['image']['tmp_name'])) {
$imgg=basename($_FILES["image"]["name"]);
$tpathh=$_FILES["image"]["tmp_name"];
 $pathh="images/".$imgg;
move_uploaded_file($tpathh,$pathh);
}
else
{
$pathh=$_POST['oimage'];
}
$oid=$_POST['oid'];


$insert=mysql_query("update gallery set image='$pathh' where id='$oid'");
if($insert){
?>
<script>alert(' Details Updated ! ');</script>
<?php
}
else{
?>
<script>alert('  Details Not Updated ! ');</script>
<?php
}

}
//update end
//add
if(isset($_POST['add'])){

if (is_uploaded_file($_FILES['image']['tmp_name'])) {
$imgg=basename($_FILES["image"]["name"]);
$tpathh=$_FILES["image"]["tmp_name"];
 $pathh="images/".$imgg;
move_uploaded_file($tpathh,$pathh);
}
else
{
$pathh=$_POST['oimage'];
}



$insert=mysql_query("insert into gallery(image) values('$pathh')");
if($insert){
?>
<script>alert(' Details Added ! ');</script>
<?php
}
else{
?>
<script>alert('  Details Not Added ! ');</script>
<?php
}

}
//add end
//delete start
if(isset($_GET['did'])){
$did=$_GET['did'];



$insert=mysql_query("delete from gallery where id='$did'");
if($insert){
?>
<script>alert(' Details Deleted ! ');
</script>
<?php
}
else{
?>
<script>alert('  Details Not Deleted ! ');</script>
<?php
}

}
//delete end
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
<div class="content">

<div class="title"><br>
<h3 style="margin:10px;color:gray">Slider Images</h3><hr>
</div>
<button type="button" data-toggle="modal" class="btn btn-primary" data-target="#myModaladd"><i class="fa fa-plus-circle" aria-hidden="true"></i>&nbsp;Add New Image
</button>



 <div class="box">
            <div class="box-header">
        <!--     
<img src="pdf.png" id="cms" style="width:30px;height:30px;cursor:pointer"/>

<a href="party_excel.php"><img src="excel.png" style="width:30px;height:30px;"/></a>

<img src="printer.png" onclick="PrintDiv();" style="width:30px;height:30px;cursor:pointer"/>
-->

            </div>
            <!-- /.box-header -->
            <div class="box-body" id="print">
              <table id="example1" class="table table-bordered table-striped" style="width:100%;">
                <thead>
               <tr>
                   <th>S.no.</th>
                  <th>Image</th>
                  <th>Delete</th>
                  <th>Update</th>
                </tr>
                </thead>
                <tbody>
<?php
$rr=mysql_query("SELECT * from gallery order by id desc");
$nr=0;
while($rrr=mysql_fetch_array($rr))
{
$nr++;
$image=$rrr['image'];
$id=$rrr['id'];



?>
<tr>
<td><?php echo $nr; ?></td>
<td><img src='<?php echo $image;?>' style="width:200px;"/></td>
<td><a onclick="return confirm('are you sure to delete?')" href=manage_gallery.php?did=<?php echo $id;?>><button><i class="fa fa-trash-o" aria-hidden="true"></i></button>
</a></font></td>


<td>

<!-- model open-->

<!-- Trigger the modal with a button -->
<button type="button"  data-toggle="modal" data-target="#myModal<?php echo $nr;?>"><i class="fa fa-refresh" aria-hidden="true"></i>
</button>

<!-- model end-->

</td>
</tr>
<?php
}
?>


</table>
<?php print_r($rrr);?>


</div>


</div>
</div>

<?php 
$nr=0;
$result1=mysql_query("SELECT * from gallery order by id desc");

while($rr=mysql_fetch_array($result1))

{
$nr++;
$aaaa=$rr['name'];
?>

  <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $nr;?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update  Details</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="manage_gallery.php" enctype="multipart/form-data">
<div class="box-body" style="width:70%">

                <div class="form-group">
                  <label>Image</label>
Current Image :<b> <img src="<?php echo $rr['image'];?>" width="100px" ><br>
Browse & Change Image :</b> <input type="file" name="image" style="width:60%;">
                </div>

   
<input type="hidden" class="form-control"  value="<?php echo $rr['id']; ?>"  name="oid" placeholder="Label Size ">
<input type="hidden" class="form-control"  value="<?php echo $rr['image']; ?>"  name="oimage" >



<div class="box-footer">
                <button type="submit" name="update" class="btn btn-primary">Update</button>
              </div>
                
              </div>

</form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      
      
    </div>
  </div>
  
</div>

<?php
}


?>
 <!-- Modal -->
  <div class="modal fade" id="myModaladd" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add New Image </h4>
        </div>
        <div class="modal-body">
          <form method="post" action="manage_gallery.php" enctype="multipart/form-data">
<div class="box-body" style="width:70%">
      <div class="form-group">
                  <label>Image</label>
 Image :</b> <input type="file" required name="image" style="width:60%;">
                </div>




<div class="box-footer">
                <button type="submit" name="add" class="btn btn-primary">Add</button>
              </div>
                
              </div>

</form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      
      
    </div>
  </div>
  
</div>

<?php include('footer.php');?>


















