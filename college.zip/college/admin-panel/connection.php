<?php
$conn=mysql_connect("localhost","root","");
$db=mysql_select_db("college",$conn);

//$conn=mysql_connect("localhost","triplear_triple","triple@123#");
//$db=mysql_select_db("triplear_triple",$conn);


?>