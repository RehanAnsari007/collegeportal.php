<?php 

include('header.php');

include('datatable.php');



if(isset($_POST['update'])){

$name=mysql_real_escape_string($_POST['name']);
$username=mysql_real_escape_string($_POST['username']);
$password=mysql_real_escape_string($_POST['password']);
	
	
	
$oid=$_POST['oid'];

$insert=mysql_query("update faculty set name='$name',username='$username',password='$password' where id='$oid'");

if($insert){

?>

<script>alert('Updated ! ');</script>

<?php

}

else{

?>

<script>alert('Not Updated ! ');</script>

<?php

}



}

//insert data





if(isset($_POST['submit'])){

$name=mysql_real_escape_string($_POST['name']);
$username=mysql_real_escape_string($_POST['username']);
$password=mysql_real_escape_string($_POST['password']);
	
	
	
	
	
	
	//,state_id,city_id
	//,'$state_id','$city_id'
$insert=mysql_query("insert into faculty (name,username,password)
 values('$name','$username','$password')");

if($insert){

?>

<script>alert('added ! ');</script>

<?php

}

else{

?>

<script>alert(' Not added ! ');</script>

<?php

}



}



if(isset($_REQUEST['did'])){

$did=$_REQUEST['did'];

$insert=mysql_query("delete from faculty where id='$did'");

if($insert){

?>

<script>alert('Deleted ! ');
document.location="faculties.php";</script>

<?php

}

else{

?>

<script>

document.location='faculties.php';

</script>



<?php

}



}

?>
<script type="text/javascript">
  $(document).ready(function(){ /* PREPARE THE SCRIPT */
    $("#state_id").change(function(){ /* WHEN YOU CHANGE AND SELECT FROM THE SELECT FIELD */
      var state_id = $(this).val(); /* GET THE VALUE OF THE SELECTED DATA */
      var dataString = "state_id="+state_id; /* STORE THAT TO A DATA STRING */

      $.ajax({ /* THEN THE AJAX CALL */
        type: "POST", /* TYPE OF METHOD TO USE TO PASS THE DATA */
        url: "get_cities.php", /* PAGE WHERE WE WILL PASS THE DATA */
        data: dataString, /* THE DATA WE WILL BE PASSING */
        success: function(result){ /* GET THE TO BE RETURNED DATA */
          $("#city_id").html(result); /* THE RETURNED DATA WILL BE SHOWN IN THIS DIV */
        }
      });

    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){ /* PREPARE THE SCRIPT */
    $("#state_id2").change(function(){ /* WHEN YOU CHANGE AND SELECT FROM THE SELECT FIELD */
      var state_id = $(this).val(); /* GET THE VALUE OF THE SELECTED DATA */
      var dataString = "state_id="+state_id; /* STORE THAT TO A DATA STRING */

      $.ajax({ /* THEN THE AJAX CALL */
        type: "POST", /* TYPE OF METHOD TO USE TO PASS THE DATA */
        url: "get_cities.php", /* PAGE WHERE WE WILL PASS THE DATA */
        data: dataString, /* THE DATA WE WILL BE PASSING */
        success: function(result){ /* GET THE TO BE RETURNED DATA */
          $("#city_id2").html(result); /* THE RETURNED DATA WILL BE SHOWN IN THIS DIV */
        }
      });

    });
  });
</script>
 <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

<div class="content">



<div class="title"><br>

<h3 style="margin:10px;color:gray">Faculty List</h3><hr>

</div>









 <div class="box">

            <div class="box-header">

              

<!--<img src="pdf.png" id="cms" style="width:30px;height:30px;cursor:pointer"/>



<a href="label_excel.php"><img src="excel.png" style="width:30px;height:30px;"/></a>



<img src="printer.png" onclick="PrintDiv();" style="width:30px;height:30px;cursor:pointer"/>-->

<!-- Trigger the modal with a button -->

  <button type="button"  data-toggle="modal" class="btn btn-primary" data-target="#myModal">
  <i class="fa fa-plus-circle" aria-hidden="true"></i>

&nbsp;Add New Faculty

</button>



            </div>

            <!-- /.box-header -->

            <div class="box-body" id="print">

              <table id="example" class="table table-bordered table-striped">

                <thead>

                <tr>

                  <th>S.no.</th>

                  <th>Name</th>
					<th>Username</th>
<th>Password</th>

                  <th>Delete</th>

				  <th>Edit</th>

                </tr>

                </thead>

                <tbody>

<?php

$result=mysql_query("SELECT * from faculty order by id desc");

$nr=0;

while($res=mysql_fetch_array($result))



{

$nr++;

$name=$res['name'];
$username=$res['username'];
$password=$res['password'];

$id=$res['id'];



?>

<tr>

<td><?php echo $nr;?></td>

<td><?php echo $name;?></td>
<td><?php echo $username;?></td>
<td><?php echo $password;?></td>


<td><a onclick="return confirm('are you sure to delete?')" href=faculties.php?did=<?php echo $id;?>><button><i class="fa fa-trash-o" aria-hidden="true"></i></button>

</a></font></td>



<td>



<!-- model open-->



<!-- Trigger the modal with a button -->

  <button type="button"  data-toggle="modal"  data-target="#myModal<?php echo $nr;?>"><i class="fa fa-refresh" aria-hidden="true"></i> 

</button>



<!-- model end-->









</td>

</tr>

<?php

}

?>





</table>



</div>





</div>

</div>

<?php 

$nn=0;

$rrs=mysql_query("SELECT * from faculty order by id desc");

while($rr= mysql_fetch_array($rrs)){

$nn++;

$name=$rr['name'];
$username=$rr['username'];
$password=$rr['password'];


$id=$rr['id'];
extract($rr);



?>



  <!-- Modal -->

  <div class="modal fade" id="myModal<?php echo $nn;?>" role="dialog">

    <div class="modal-dialog">

    

      <!-- Modal content-->

      <div class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title">Update Details</h4>

        </div>

        <div class="modal-body">

          <form method="post" action="" enctype="multipart/form-data">

<div class="box-body" style="width:70%">

                



                



<input type="hidden" class="form-control"  value="<?php echo $id; ?>"  name="oid">



                </div>

				<div class="form-group">

                  <label>Faculty Name</label>

                  <input type="text" class="form-control" value="<?php echo $name; ?>" id="no" name="name" placeholder="Name">

                </div>
				<div class="form-group">

                  <label>Username</label>

                  <input type="text" class="form-control" value="<?php echo $username; ?>" id="no" name="username" placeholder="Username">

                </div>
				
				<div class="form-group">

                  <label>Password</label>

                  <input type="text" class="form-control" value="<?php echo $password; ?>" id="no" name="password" placeholder="Password">

                </div>
				
<div class="clearfix"></div>

<div class="box-footer">

                <button type="submit" name="update" class="btn btn-primary">Update</button> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        

              </div>

                

              </div>



</form>



        </div>

       

      

    </div>

  </div>

  

</div>



<?php

}





?>

<!--add new start-->

<!-- Modal -->

  <div class="modal fade" id="myModal" role="dialog">

    <div class="modal-dialog">

    

      <!-- Modal content-->

      <div class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title">Add New Faculty</h4>

        </div>

        <div class="modal-body">

          <form method="post" action="" enctype="multipart/form-data">

<div class="box-body" style="width:70%">

             
				<div class="form-group">

                  <label>Name</label>

                  <input type="text" class="form-control"  id="no" name="name" placeholder="Name">

                </div>
				<div class="form-group">

                  <label>Username</label>

                  <input type="text" class="form-control"  id="no" name="username" placeholder="Username">

                </div>
				
				<div class="form-group">

                  <label>Password</label>

                  <input type="text" class="form-control"  id="no" name="password" placeholder="Password">

                </div>

<div class="clearfix"></div>
             <div class="box-footer">

                <button type="submit" name="submit" class="btn btn-primary">Submit</button>

              </div>

                

              </div>



</form>



        </div>

        <div class="modal-footer">

          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        </div>

      

      

    </div>

  </div>



</div>







<!--add new end-->

























































<?php include('footer.php');?>