<?php 
include('header.php');?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
<div class="content">

<div class="title"><br>
<h3 style="margin:10px;color:gray">label Report</h3><hr>
</div>

<form>
 <div class="box">
            
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>S.no.</th>
                  <th>Party_Name</th>
                  <th>Label Size </th>
                  <th>No. Of Labels</th>

                  
                </tr>
                </thead>
                <tbody>
                <tr>
                  
                  <td>demo </td>
                  <td> demo</td> <td> demo</td> <td> demo</td>
                
                </tr><tr>
                  <td>demo</td>
                  <td>demo
                    
                  </td>
                  <td>demo </td>
                  <td> demo</td> 
                </tr>


</table>
            </div>






















</form>

</div>
</div>
</div>

<?php include('footer.php');?>