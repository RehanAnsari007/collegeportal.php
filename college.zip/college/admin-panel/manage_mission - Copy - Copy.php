<?php 
include('header2.php');
$id=$_GET['id'];
$select =mysql_query("select * from mission where id='1'");
$res=mysql_fetch_array($select);

if(isset($_POST['update'])){
$title=mysql_real_escape_string($_POST['title']);
$content=mysql_real_escape_string($_POST['content']);

if (is_uploaded_file($_FILES['image']['tmp_name'])) {
$imgg=basename($_FILES["image"]["name"]);
$tpathh=$_FILES["image"]["tmp_name"];
 $pathh="images/".$imgg;
move_uploaded_file($tpathh,$pathh);
}
else
{
$pathh=$_POST['oldimage'];
}

$insert=mysql_query("update mission set title='$title',content='$content',image='$pathh' where id='1'");
if($insert){
?>
<script>alert('Mission Updated ! ');
window.location.href='index2.php?list=true';
</script>
<?php
}
}
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">

<div class="content">
<div class="title"><br>
<h4 class="red" style="margin:10px;">Update Mission</h4><hr>
</div>
<form name="frm" action="" method="post" enctype="multipart/form-data">
<!--b> Title :</b> --><input type="hidden" name="title" value="<?php echo $res['title'];?>" style="width:60%;"><br><br>
<script src="ckeditor/ckeditor.js"></script>
        <script src="ckeditor/config.js"></script>

<b> Content :</b> <textarea  id="editor1"  name="content" ><?php echo $res['content'];?></textarea><br><br>
 <script>
               CKEDITOR.replace( 'editor1' );
            </script>
<br><b>Current Image :<b> <img src="<?php echo $res['image'];?>" width="80px" height="80px"><br><br>
<b> Browse & Change Image :</b> <input type="file" name="image" style="width:60%;"><br><br>
<input type="hidden" value="<?php echo $res['image'];?>" name="oldimage">
<input class="black" type="submit" name="update" value="Update"><hr>
</form>
<?php // echo $urll;?>
</div>
</div>
</div>

<?php include('footer.php');?>
