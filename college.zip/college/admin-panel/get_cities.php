<?php

include('connection.php'); 
if(!empty($_REQUEST["state_id"])){ 
$state_id=$_REQUEST['state_id'];
    // Fetch city data based on the specific state 
    $query = "SELECT * FROM cities WHERE state_id = '$state_id'"; 
    $result = mysql_query($query); 
     
    // Generate HTML of city options list 
    if(mysql_num_rows($result) > 0){ 
         
        while($row = mysql_fetch_assoc($result)){  
            echo '<option value="'.$row['id'].'">'.$row['city'].'</option>'; 
        } 
    }else{ 
        echo '<option value="">City not available</option>'; 
    } 
}

?>