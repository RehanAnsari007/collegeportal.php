<?php
$conn=mysql_connect("localhost","manuf712_gekatex","geka987#");
$db=mysql_select_db("manuf712_gekatex",$conn);
?>
