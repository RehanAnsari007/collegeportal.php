<?php 
include('header.php');
include('datatable.php');

if(isset($_POST['update'])){
$description=mysql_real_escape_string($_POST['description']);$aa=mysql_real_escape_string($_POST['name']);if (!is_uploaded_file($_FILES['photo']['tmp_name'])) 	{			$p1=$_REQUEST['oldpic'];         }	else	{ 	$thumb=basename($_FILES["photo"]["name"]);$tpath1=$_FILES["photo"]["tmp_name"]; $path1="uploads/".$thumb;$p1="$path1";move_uploaded_file($tpath1,$path1);			}	
$oid=$_POST['oid'];
$insert=mysql_query("update category set name='$aa',photo='$p1',description='$description' where id='$oid'");
if($insert){
?>
<script>alert('category Updated ! ');</script>
<?php
}
else{
?>
<script>alert(' category Not Updated ! ');</script>
<?php
}

}
//insert data


if(isset($_POST['submit'])){
$aa=mysql_real_escape_string($_POST['name']);$description=mysql_real_escape_string($_POST['description']);if (!is_uploaded_file($_FILES['photo']['tmp_name'])) 	{			$p1="";         }	else	{ 	$thumb=basename($_FILES["photo"]["name"]);$tpath1=$_FILES["photo"]["tmp_name"]; $path1="uploads/".$thumb;$p1="$path1";move_uploaded_file($tpath1,$path1);			}
$insert=mysql_query("insert into category (name,description,photo) values('$aa','$description','$p1')");
if($insert){
?>
<script>alert('category added ! ');</script>
<?php
}
else{
?>
<script>alert(' category Not added ! ');</script>
<?php
}

}

if(isset($_REQUEST['did'])){
$did=$_REQUEST['did'];
$insert=mysql_query("delete from category where id='$did'");
if($insert){
?>
<script>alert('Category Deleted ! ');</script>
<?php
}
else{
?>
<script>
document.location='categories.php';
</script>

<?php
}

}
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
<div class="content">

<div class="title"><br>
<h3 style="margin:10px;color:gray">Categories</h3><hr>
</div>




 <div class="box">
            <div class="box-header">
              
<!--<img src="pdf.png" id="cms" style="width:30px;height:30px;cursor:pointer"/>

<a href="label_excel.php"><img src="excel.png" style="width:30px;height:30px;"/></a>

<img src="printer.png" onclick="PrintDiv();" style="width:30px;height:30px;cursor:pointer"/>-->
<!-- Trigger the modal with a button -->
  <button type="button"  data-toggle="modal" class="btn btn-primary" data-target="#myModal"><i class="fa fa-plus-circle" aria-hidden="true"></i>
&nbsp;Add New Category
</button>

            </div>
            <!-- /.box-header -->
            <div class="box-body" id="print">
              <table id="example" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>S.no.</th>                  <th>Category name</th>                  <th>Category Photo</th><th>Description</th>
                  <th>Delete</th>
				  <th>Edit</th>
                </tr>
                </thead>
                <tbody>
<?php
$result=mysql_query("SELECT * from category order by id desc");
$nr=0;
while($res=mysql_fetch_array($result))

{
$nr++;
$aa=$res['name'];$description=$res['description'];$photo=$res['photo'];
$id=$res['id'];

?>
<tr>
<td><?php echo $nr;?></td><td><?php echo $aa;?></td><td><img src="<?php echo $photo;?>" style="width:100px;"></td><td><?php echo $description;?></td>
<td><a onclick="return confirm('are you sure to delete?')" href=categories.php?did=<?php echo $id;?>><button><i class="fa fa-trash-o" aria-hidden="true"></i></button>
</a></font></td>

<td>

<!-- model open-->

<!-- Trigger the modal with a button -->
  <button type="button"  data-toggle="modal"  data-target="#myModal<?php echo $nr;?>"><i class="fa fa-refresh" aria-hidden="true"></i> 
</button>

<!-- model end-->




</td>
</tr>
<?php
}
?>


</table>

</div>


</div>
</div>
<?php 
$nn=0;
$rrs=mysql_query("SELECT * from category order by id desc");
while($rr= mysql_fetch_array($rrs)){
$nn++;
$aaa=$rr['name'];$photo=$rr['photo'];$description=$rr['description'];

$id=$rr['id'];
?>

  <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $nn;?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update Category Details</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="" enctype="multipart/form-data">
<div class="box-body" style="width:70%">
                

                

<input type="hidden" class="form-control"  value="<?php echo $id; ?>"  name="oid">

                </div>
<div class="form-group">                  <label>Category Name</label>                  <input type="text" class="form-control" value="<?php echo $aaa; ?>" id="no" name="name" placeholder="Name">                </div>				<div class="form-group">                  <label>Category Icon Image</label>                  <input type="file" class="form-control" id="" name="photo" required>				  <img src="<?php echo $photo; ?>" style="width:60px;"><input type="hidden" class="form-control" id="" name="oldpic" required>                </div><div class="form-group">                  <label>Description</label> <textarea type="text" class="form-control"  name="description" placeholder="Description"> <?php echo $description; ?></textarea>                </div>

<div class="box-footer">
                <button type="submit" name="update" class="btn btn-primary">Update</button> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
              </div>
                
              </div>

</form>

        </div>
       
      
    </div>
  </div>
  
</div>

<?php
}


?>
<!--add new start-->
<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add New Category</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="" enctype="multipart/form-data">
<div class="box-body" style="width:70%">
                <div class="form-group">                  <label>Category Name</label>                  <input type="text" class="form-control" id="" name="name" placeholder="Category Name" required>                </div>  				<div class="form-group">                  <label>Category Icon Image</label>                  <input type="file" class="form-control" id="" name="photo" required>                </div>
<div class="form-group">                  <label>Description</label> <textarea type="text" class="form-control"  name="description" placeholder="Description"></textarea>                </div>

             <div class="box-footer">
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
              </div>
                
              </div>

</form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      
      
    </div>
  </div>

</div>



<!--add new end-->




























<?php include('footer.php');?>