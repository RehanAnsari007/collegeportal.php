<?php 

include('header.php');

include('datatable.php');



if(isset($_POST['update'])){

$builtup_area=mysql_real_escape_string($_POST['builtup_area']);
$carpet_area=mysql_real_escape_string($_POST['carpet_area']);
$description=mysql_real_escape_string($_POST['description']);
$aa=mysql_real_escape_string($_POST['name']);
$sub_location=mysql_real_escape_string($_POST['sub_location']);

$price=mysql_real_escape_string($_POST['price']);
$category=mysql_real_escape_string($_POST['category']);
$property_type=mysql_real_escape_string($_POST['property_type']);
$possession_type=mysql_real_escape_string($_POST['possession_type']);
$purchase_type=mysql_real_escape_string($_POST['purchase_type']);

$phototitle=mysql_real_escape_string($_POST['phototitle']);
$photo2title=mysql_real_escape_string($_POST['photo2title']);
$photo3title=mysql_real_escape_string($_POST['photo3title']);
$photo4title=mysql_real_escape_string($_POST['photo4title']);
$photo5title=mysql_real_escape_string($_POST['photo5title']);
$photo6title=mysql_real_escape_string($_POST['photo6title']);
$photo7title=mysql_real_escape_string($_POST['photo7title']);
$photo8title=mysql_real_escape_string($_POST['photo8title']);
$photo9title=mysql_real_escape_string($_POST['photo9title']);
$photo10title=mysql_real_escape_string($_POST['photo10title']);
$photo11title=mysql_real_escape_string($_POST['photo11title']);
$photo12title=mysql_real_escape_string($_POST['photo12title']);
$photo13title=mysql_real_escape_string($_POST['photo13title']);
$photo14title=mysql_real_escape_string($_POST['photo14title']);
$photo15title=mysql_real_escape_string($_POST['photo15title']);



//$state_id=mysql_real_escape_string($_POST['state_id']);
//$city_id=mysql_real_escape_string($_POST['city_id']);


if (!is_uploaded_file($_FILES['photo']['tmp_name'])) 
	{	
		$p1=$_REQUEST['oldpic'];
         }
	else
	{ 
	

$thumb=basename($_FILES["photo"]["name"]);
$tpath1=$_FILES["photo"]["tmp_name"];
 $path1="uploads/".$thumb;
$p1="$path1";

move_uploaded_file($tpath1,$path1);
		
	}
	
if (!is_uploaded_file($_FILES['photo2']['tmp_name'])) 
	{	
		$p2=$_REQUEST['oldpic2'];
         }
	else
	{ 
	

$thumb2=basename($_FILES["photo2"]["name"]);
$tpath2=$_FILES["photo2"]["tmp_name"];
 $path2="uploads/".$thumb2;
$p2="$path2";

move_uploaded_file($tpath2,$path2);
		
	}
	
if (!is_uploaded_file($_FILES['photo3']['tmp_name'])) 
	{	
		$p3=$_REQUEST['oldpic3'];
         }
	else
	{ 
	

$thumb3=basename($_FILES["photo3"]["name"]);
$tpath3=$_FILES["photo3"]["tmp_name"];
 $path3="uploads/".$thumb3;
$p3="$path3";

move_uploaded_file($tpath3,$path3);
		
	}
	
if (!is_uploaded_file($_FILES['photo4']['tmp_name'])) 
	{	
		$p4=$_REQUEST['oldpic4'];
         }
	else
	{ 
	

$thumb4=basename($_FILES["photo4"]["name"]);
$tpath4=$_FILES["photo4"]["tmp_name"];
 $path4="uploads/".$thumb4;
$p4="$path4";

move_uploaded_file($tpath4,$path4);
		
	}
	
	//4 end
	if (!is_uploaded_file($_FILES['photo5']['tmp_name'])) 
	{	
		$p5=$_REQUEST['oldpic5'];
         }
	else
	{ 
	

$thumb5=basename($_FILES["photo5"]["name"]);
$tpath5=$_FILES["photo5"]["tmp_name"];
 $path5="uploads/".$thumb5;
$p5="$path5";

move_uploaded_file($tpath5,$path5);
		
	}
	//5 end
	if (!is_uploaded_file($_FILES['photo6']['tmp_name'])) 
	{	
		$p6=$_REQUEST['oldpic6'];
         }
	else
	{ 
	

$thumb6=basename($_FILES["photo6"]["name"]);
$tpath6=$_FILES["photo6"]["tmp_name"];
 $path6="uploads/".$thumb6;
$p6="$path6";

move_uploaded_file($tpath6,$path6);
		
	}
	//6 end
	
	if (!is_uploaded_file($_FILES['photo7']['tmp_name'])) 
	{	
		$p7=$_REQUEST['oldpic7'];
         }
	else
	{ 
	

$thumb7=basename($_FILES["photo7"]["name"]);
$tpath7=$_FILES["photo7"]["tmp_name"];
 $path7="uploads/".$thumb7;
$p7="$path7";

move_uploaded_file($tpath7,$path7);
		
	}
	//7 end
	if (!is_uploaded_file($_FILES['photo8']['tmp_name'])) 
	{	
		$p8=$_REQUEST['oldpic8'];
         }
	else
	{ 
	

$thumb8=basename($_FILES["photo8"]["name"]);
$tpath8=$_FILES["photo8"]["tmp_name"];
 $path8="uploads/".$thumb8;
$p8="$path8";

move_uploaded_file($tpath8,$path8);
		
	}
	//8 end
	if (!is_uploaded_file($_FILES['photo9']['tmp_name'])) 
	{	
		$p9=$_REQUEST['oldpic9'];
         }
	else
	{ 
	

$thumb9=basename($_FILES["photo9"]["name"]);
$tpath9=$_FILES["photo9"]["tmp_name"];
 $path9="uploads/".$thumb9;
$p9="$path9";

move_uploaded_file($tpath9,$path9);
		
	}
	//9 end
	if (!is_uploaded_file($_FILES['photo10']['tmp_name'])) 
	{	
		$p10=$_REQUEST['oldpic10'];
         }
	else
	{ 
	

$thumb10=basename($_FILES["photo10"]["name"]);
$tpath10=$_FILES["photo10"]["tmp_name"];
 $path10="uploads/".$thumb10;
$p10="$path10";

move_uploaded_file($tpath10,$path10);
		
	}
	//10 end
	if (!is_uploaded_file($_FILES['photo11']['tmp_name'])) 
	{	
		$p11=$_REQUEST['oldpic11'];
         }
	else
	{ 
	

$thumb11=basename($_FILES["photo11"]["name"]);
$tpath11=$_FILES["photo11"]["tmp_name"];
 $path11="uploads/".$thumb11;
$p11="$path11";

move_uploaded_file($tpath11,$path11);
		
	}
	//11 end
	if (!is_uploaded_file($_FILES['photo12']['tmp_name'])) 
	{	
		$p12=$_REQUEST['oldpic12'];
         }
	else
	{ 
	

$thumb12=basename($_FILES["photo12"]["name"]);
$tpath12=$_FILES["photo12"]["tmp_name"];
 $path12="uploads/".$thumb12;
$p12="$path12";

move_uploaded_file($tpath12,$path12);
		
	}
	//12 end
	if (!is_uploaded_file($_FILES['photo13']['tmp_name'])) 
	{	
		$p13=$_REQUEST['oldpic13'];
         }
	else
	{ 
	

$thumb13=basename($_FILES["photo13"]["name"]);
$tpath13=$_FILES["photo13"]["tmp_name"];
 $path13="uploads/".$thumb13;
$p13="$path13";

move_uploaded_file($tpath13,$path13);
		
	}
	//13 end
	if (!is_uploaded_file($_FILES['photo14']['tmp_name'])) 
	{	
		$p14=$_REQUEST['oldpic14'];
         }
	else
	{ 
	

$thumb14=basename($_FILES["photo14"]["name"]);
$tpath14=$_FILES["photo14"]["tmp_name"];
 $path14="uploads/".$thumb14;
$p14="$path14";

move_uploaded_file($tpath14,$path14);
		
	}
	//14 end
	if (!is_uploaded_file($_FILES['photo15']['tmp_name'])) 
	{	
		$p15=$_REQUEST['oldpic15'];
         }
	else
	{ 
	

$thumb15=basename($_FILES["photo15"]["name"]);
$tpath15=$_FILES["photo15"]["tmp_name"];
 $path15="uploads/".$thumb15;
$p15="$path15";

move_uploaded_file($tpath15,$path15);
		
	}
	//15 end
	
	
	
$oid=$_POST['oid'];
//,state_id='$state_id',city_id='$city_id'
$insert=mysql_query("update property set builtup_area='$builtup_area',carpet_area='$carpet_area',sub_location='$sub_location',name='$aa',possession_type='$possession_type',photo='$p1',photo2='$p2',photo3='$p3',
photo4='$p4',photo5='$p5',photo6='$p6',photo7='$p7',photo8='$p8',photo9='$p9',photo10='$p10',photo11='$p11',photo12='$p12',photo13='$p13',photo14='$p14',photo15='$p15',

phototitle='$phototitle',photo2title='$photo2title',photo3title='$photo3title',photo4title='$photo4title',
photo5title='$photo5title',photo6title='$photo6title',photo7title='$photo7title',photo8title='$photo8title',
photo9title='$photo9title',photo10title='$photo10title',photo11title='$photo11title',photo12title='$photo12title',
photo13title='$photo13title',photo14title='$photo14title',photo15title='$photo15title',

description='$description',price='$price',category='$category',property_type='$property_type',purchase_type='$purchase_type' where id='$oid'");

if($insert){

?>

<script>alert('property Updated ! ');</script>

<?php

}

else{

?>

<script>alert(' property Not Updated ! ');</script>

<?php

}



}

//insert data





if(isset($_POST['submit'])){

$aa=mysql_real_escape_string($_POST['name']);
$sub_location=mysql_real_escape_string($_POST['sub_location']);
$price=mysql_real_escape_string($_POST['price']);
$category=mysql_real_escape_string($_POST['category']);
$property_type=mysql_real_escape_string($_POST['property_type']);
$possession_type=mysql_real_escape_string($_POST['possession_type']);

$builtup_area=mysql_real_escape_string($_POST['builtup_area']);
$carpet_area=mysql_real_escape_string($_POST['carpet_area']);
$purchase_type=mysql_real_escape_string($_POST['purchase_type']);
//$state_id=mysql_real_escape_string($_POST['state_id']);
//$city_id=mysql_real_escape_string($_POST['city_id']);
$description=mysql_real_escape_string($_POST['description']);

$phototitle=mysql_real_escape_string($_POST['phototitle']);
$photo2title=mysql_real_escape_string($_POST['photo2title']);
$photo3title=mysql_real_escape_string($_POST['photo3title']);
$photo4title=mysql_real_escape_string($_POST['photo4title']);
$photo5title=mysql_real_escape_string($_POST['photo5title']);
$photo6title=mysql_real_escape_string($_POST['photo6title']);
$photo7title=mysql_real_escape_string($_POST['photo7title']);
$photo8title=mysql_real_escape_string($_POST['photo8title']);
$photo9title=mysql_real_escape_string($_POST['photo9title']);
$photo10title=mysql_real_escape_string($_POST['photo10title']);
$photo11title=mysql_real_escape_string($_POST['photo11title']);
$photo12title=mysql_real_escape_string($_POST['photo12title']);
$photo13title=mysql_real_escape_string($_POST['photo13title']);
$photo14title=mysql_real_escape_string($_POST['photo14title']);
$photo15title=mysql_real_escape_string($_POST['photo15title']);


if (!is_uploaded_file($_FILES['photo']['tmp_name'])) 
	{	
		$p1=$_REQUEST['oldpic'];
         }
	else
	{ 
	

$thumb=basename($_FILES["photo"]["name"]);
$tpath1=$_FILES["photo"]["tmp_name"];
 $path1="uploads/".$thumb;
$p1="$path1";

move_uploaded_file($tpath1,$path1);
		
	}
	if (!is_uploaded_file($_FILES['photo2']['tmp_name'])) 
	{	
		$p2=$_REQUEST['oldpic2'];
         }
	else
	{ 
	

$thumb2=basename($_FILES["photo2"]["name"]);
$tpath2=$_FILES["photo2"]["tmp_name"];
 $path2="uploads/".$thumb2;
$p2="$path2";

move_uploaded_file($tpath2,$path2);
		
	}
	if (!is_uploaded_file($_FILES['photo3']['tmp_name'])) 
	{	
		$p3=$_REQUEST['oldpic3'];
         }
	else
	{ 
	

$thumb3=basename($_FILES["photo3"]["name"]);
$tpath3=$_FILES["photo3"]["tmp_name"];
 $path3="uploads/".$thumb3;
$p3="$path3";

move_uploaded_file($tpath3,$path3);
		
	}
	if (!is_uploaded_file($_FILES['photo4']['tmp_name'])) 
	{	
		$p4=$_REQUEST['oldpic4'];
         }
	else
	{ 
	

$thumb4=basename($_FILES["photo4"]["name"]);
$tpath4=$_FILES["photo4"]["tmp_name"];
 $path4="uploads/".$thumb4;
$p4="$path4";

move_uploaded_file($tpath4,$path4);
		
	}
	if (!is_uploaded_file($_FILES['photo5']['tmp_name'])) 
	{	
		$p5=$_REQUEST['oldpic5'];
         }
	else
	{ 
	

$thumb5=basename($_FILES["photo5"]["name"]);
$tpath5=$_FILES["photo5"]["tmp_name"];
 $path5="uploads/".$thumb5;
$p5="$path5";

move_uploaded_file($tpath5,$path5);
		
	}
	
	if (!is_uploaded_file($_FILES['photo6']['tmp_name'])) 
	{	
		$p6=$_REQUEST['oldpic6'];
         }
	else
	{ 
	

$thumb6=basename($_FILES["photo6"]["name"]);
$tpath6=$_FILES["photo6"]["tmp_name"];
 $path6="uploads/".$thumb6;
$p6="$path6";

move_uploaded_file($tpath6,$path6);
		
	}
	
	if (!is_uploaded_file($_FILES['photo7']['tmp_name'])) 
	{	
		$p7=$_REQUEST['oldpic7'];
         }
	else
	{ 
	

$thumb7=basename($_FILES["photo7"]["name"]);
$tpath7=$_FILES["photo7"]["tmp_name"];
 $path7="uploads/".$thumb7;
$p7="$path7";

move_uploaded_file($tpath7,$path7);
		
	}
	if (!is_uploaded_file($_FILES['photo8']['tmp_name'])) 
	{	
		$p8=$_REQUEST['oldpic8'];
         }
	else
	{ 
	

$thumb8=basename($_FILES["photo8"]["name"]);
$tpath8=$_FILES["photo8"]["tmp_name"];
 $path8="uploads/".$thumb8;
$p8="$path8";

move_uploaded_file($tpath8,$path8);
		
	}
	if (!is_uploaded_file($_FILES['photo9']['tmp_name'])) 
	{	
		$p9=$_REQUEST['oldpic9'];
         }
	else
	{ 
	

$thumb9=basename($_FILES["photo9"]["name"]);
$tpath9=$_FILES["photo9"]["tmp_name"];
 $path9="uploads/".$thumb9;
$p9="$path9";

move_uploaded_file($tpath9,$path9);
		
	}
	if (!is_uploaded_file($_FILES['photo10']['tmp_name'])) 
	{	
		$p10=$_REQUEST['oldpic10'];
         }
	else
	{ 
	

$thumb10=basename($_FILES["photo10"]["name"]);
$tpath10=$_FILES["photo10"]["tmp_name"];
 $path10="uploads/".$thumb10;
$p10="$path10";

move_uploaded_file($tpath10,$path10);
		
	}
	if (!is_uploaded_file($_FILES['photo11']['tmp_name'])) 
	{	
		$p11=$_REQUEST['oldpic11'];
         }
	else
	{ 
	

$thumb11=basename($_FILES["photo11"]["name"]);
$tpath11=$_FILES["photo11"]["tmp_name"];
 $path11="uploads/".$thumb11;
$p11="$path11";

move_uploaded_file($tpath11,$path11);
		
	}
	if (!is_uploaded_file($_FILES['photo12']['tmp_name'])) 
	{	
		$p12=$_REQUEST['oldpic12'];
         }
	else
	{ 
	

$thumb12=basename($_FILES["photo12"]["name"]);
$tpath12=$_FILES["photo12"]["tmp_name"];
 $path12="uploads/".$thumb12;
$p12="$path12";

move_uploaded_file($tpath12,$path12);
		
	}
	if (!is_uploaded_file($_FILES['photo13']['tmp_name'])) 
	{	
		$p13=$_REQUEST['oldpic13'];
         }
	else
	{ 
	

$thumb13=basename($_FILES["photo13"]["name"]);
$tpath13=$_FILES["photo13"]["tmp_name"];
 $path13="uploads/".$thumb13;
$p13="$path13";

move_uploaded_file($tpath13,$path13);
		
	}
	if (!is_uploaded_file($_FILES['photo14']['tmp_name'])) 
	{	
		$p14=$_REQUEST['oldpic14'];
         }
	else
	{ 
	

$thumb14=basename($_FILES["photo14"]["name"]);
$tpath14=$_FILES["photo14"]["tmp_name"];
 $path14="uploads/".$thumb14;
$p14="$path14";

move_uploaded_file($tpath14,$path14);
		
	}
	if (!is_uploaded_file($_FILES['photo15']['tmp_name'])) 
	{	
		$p15=$_REQUEST['oldpic15'];
         }
	else
	{ 
	

$thumb15=basename($_FILES["photo15"]["name"]);
$tpath15=$_FILES["photo15"]["tmp_name"];
 $path15="uploads/".$thumb15;
$p15="$path15";

move_uploaded_file($tpath15,$path15);
		
	}
	
	
	//,state_id,city_id
	//,'$state_id','$city_id'
$insert=mysql_query("insert into property (builtup_area,carpet_area,name,sub_location,description,
photo,photo2,photo3,photo4,photo5,photo6,photo7,photo8,photo9,photo10,photo11,photo12,photo13,photo14,photo15,
phototitle,photo2title,photo3title,photo4title,photo5title,photo6title,photo7title,photo8title,photo9title,photo10title,
photo11title,photo12title,photo13title,photo14title,photo15title,
price,category,possession_type,property_type,purchase_type)
 values('$builtup_area','$carpet_area','$aa','$sub_location','$description',
 '$p1','$p2','$p3','$p4','$p5','$p6','$p7','$p8','$p9','$p10','$p11','$p12','$p13','$p14','$p15'
 ,'$phototitle' ,'$photo2title' ,'$photo3title' ,'$photo4title' ,'$photo5title' ,'$photo6title' ,'$photo7title'
  ,'$photo8title' ,'$photo9title' ,'$photo10title' ,'$photo11title' ,'$photo12title' ,'$photo13title' ,'$photo14title' ,'$photo15title'
 ,'$price','$category','$possession_type','$property_type','$purchase_type')");

if($insert){

?>

<script>alert('property added ! ');</script>

<?php

}

else{

?>

<script>alert(' property Not added ! ');</script>

<?php

}



}



if(isset($_REQUEST['did'])){

$did=$_REQUEST['did'];

$insert=mysql_query("delete from property where id='$did'");

if($insert){

?>

<script>alert('Category Deleted ! ');
document.location="ads.php";</script>

<?php

}

else{

?>

<script>

document.location='ads.php';

</script>



<?php

}



}

?>
<script type="text/javascript">
  $(document).ready(function(){ /* PREPARE THE SCRIPT */
    $("#state_id").change(function(){ /* WHEN YOU CHANGE AND SELECT FROM THE SELECT FIELD */
      var state_id = $(this).val(); /* GET THE VALUE OF THE SELECTED DATA */
      var dataString = "state_id="+state_id; /* STORE THAT TO A DATA STRING */

      $.ajax({ /* THEN THE AJAX CALL */
        type: "POST", /* TYPE OF METHOD TO USE TO PASS THE DATA */
        url: "get_cities.php", /* PAGE WHERE WE WILL PASS THE DATA */
        data: dataString, /* THE DATA WE WILL BE PASSING */
        success: function(result){ /* GET THE TO BE RETURNED DATA */
          $("#city_id").html(result); /* THE RETURNED DATA WILL BE SHOWN IN THIS DIV */
        }
      });

    });
  });
</script>
<script type="text/javascript">
  $(document).ready(function(){ /* PREPARE THE SCRIPT */
    $("#state_id2").change(function(){ /* WHEN YOU CHANGE AND SELECT FROM THE SELECT FIELD */
      var state_id = $(this).val(); /* GET THE VALUE OF THE SELECTED DATA */
      var dataString = "state_id="+state_id; /* STORE THAT TO A DATA STRING */

      $.ajax({ /* THEN THE AJAX CALL */
        type: "POST", /* TYPE OF METHOD TO USE TO PASS THE DATA */
        url: "get_cities.php", /* PAGE WHERE WE WILL PASS THE DATA */
        data: dataString, /* THE DATA WE WILL BE PASSING */
        success: function(result){ /* GET THE TO BE RETURNED DATA */
          $("#city_id2").html(result); /* THE RETURNED DATA WILL BE SHOWN IN THIS DIV */
        }
      });

    });
  });
</script>
 <!-- Content Wrapper. Contains page content -->

  <div class="content-wrapper">

    <!-- Content Header (Page header) -->

    <section class="content-header">

<div class="content">



<div class="title"><br>

<h3 style="margin:10px;color:gray">Properties</h3><hr>

</div>









 <div class="box">

            <div class="box-header">

              

<!--<img src="pdf.png" id="cms" style="width:30px;height:30px;cursor:pointer"/>



<a href="label_excel.php"><img src="excel.png" style="width:30px;height:30px;"/></a>



<img src="printer.png" onclick="PrintDiv();" style="width:30px;height:30px;cursor:pointer"/>-->

<!-- Trigger the modal with a button -->

  <button type="button"  data-toggle="modal" class="btn btn-primary" data-target="#myModal"><i class="fa fa-plus-circle" aria-hidden="true"></i>

&nbsp;Add New Property

</button>



            </div>

            <!-- /.box-header -->

            <div class="box-body" id="print">

              <table id="example" class="table table-bordered table-striped">

                <thead>

                <tr>

                  <th>S.no.</th>

                  <th>Name</th>
                  <th>Photo</th>
					<th>Description</th>
<th>Other Details</th>

                  <th>Delete</th>

				  <th>Edit</th>

                </tr>

                </thead>

                <tbody>

<?php

$result=mysql_query("SELECT * from property order by id desc");

$nr=0;

while($res=mysql_fetch_array($result))



{

$nr++;

$aa=$res['name'];
$description=$res['description'];
$photo=$res['photo'];

$id=$res['id'];



?>

<tr>

<td><?php echo $nr;?></td>

<td><?php echo $aa;?></td>
<td><img src="<?php echo $photo;?>" style="width:100px;"></td>
<td><textarea cols="50" rows="8"><?php echo $description;?></textarea></td>
<td><?php 
echo "<b>Price/Rent :</b>".$res['price']."<br>";
echo "<b>Built Up Area :</b>".$res['builtup_area']."<br>";
echo "<b>Carpet Area :</b>".$res['carpet_area']."<br>";
echo "<b>Category :</b>".$res['category']."<br>";
echo "<b>Purchase Type :</b>".$res['purchase_type']."<br>";
echo "<b>Possession Type :</b>".$res['possession_type']."<br>";
echo "<b>Typology :</b>".$res['property_type']."<br>";
/*$ss = mysql_query("select * from states where id='".$res['state_id']."'");
$fetchs = mysql_fetch_array($ss);

echo "<b>State :</b>".$fetchs['name']."<br>";

$sc = mysql_query("select * from cities where id='".$res['city_id']."'");
$fetchc = mysql_fetch_array($sc);

echo "<b>City :</b>".$fetchc['city']."<br>";*/
echo "<b>Area/Sub-Location :</b>".$res['sub_location']."<br>";

?></td>

<td><a onclick="return confirm('are you sure to delete?')" href=ads.php?did=<?php echo $id;?>><button><i class="fa fa-trash-o" aria-hidden="true"></i></button>

</a></font></td>



<td>



<!-- model open-->



<!-- Trigger the modal with a button -->

  <button type="button"  data-toggle="modal"  data-target="#myModal<?php echo $nr;?>"><i class="fa fa-refresh" aria-hidden="true"></i> 

</button>



<!-- model end-->









</td>

</tr>

<?php

}

?>





</table>



</div>





</div>

</div>

<?php 

$nn=0;

$rrs=mysql_query("SELECT * from property order by id desc");

while($rr= mysql_fetch_array($rrs)){

$nn++;

$aaa=$rr['name'];

$id=$rr['id'];
extract($rr);
/*
$sub_location=$rr['sub_location'];
$builtup_area=$rr['builtup_area'];
$carpet_area=$rr['carpet_area'];
$photo=$rr['photo'];
$photo2=$rr['photo2'];
$photo3=$rr['photo3'];
$photo4=$rr['photo4'];
$description=$rr['description'];
$price  = $rr['price'];
$category = $rr['category'];
$purchase_type = $rr['purchase_type'];
$property_type = $rr['property_type'];*/

/*$ss = mysql_query("select * from states where id='".$rr['state_id']."'");
$fetchs = mysql_fetch_array($ss);


$sc = mysql_query("select * from cities where id='".$rr['city_id']."'");
$fetchc = mysql_fetch_array($sc);*/



?>



  <!-- Modal -->

  <div class="modal fade" id="myModal<?php echo $nn;?>" role="dialog">

    <div class="modal-dialog">

    

      <!-- Modal content-->

      <div class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title">Update Details</h4>

        </div>

        <div class="modal-body">

          <form method="post" action="" enctype="multipart/form-data">

<div class="box-body" style="width:70%">

                



                



<input type="hidden" class="form-control"  value="<?php echo $id; ?>"  name="oid">



                </div>

<div class="form-group">

                  <label>Property Name</label>

                  <input type="text" class="form-control" value="<?php echo $aaa; ?>" id="no" name="name" placeholder="Name">

                </div>
				
				<div class="form-group">

                  <label>Property Price/Rent</label>

                  <input type="text" class="form-control" value="<?php echo $price; ?>" id="no" name="price" placeholder="Price/Rent">

                </div>
				
				<div class="form-group">

                  <label>Built up Area(sqft)</label>

                  <input type="text" class="form-control"  id="no" value="<?php echo $builtup_area; ?>" name="builtup_area" placeholder="Built Up Area">

                </div>
				<div class="form-group">

                  <label>Carpet Area(sqft)</label>

                  <input type="text" class="form-control" id="no" value="<?php echo $carpet_area; ?>" name="carpet_area" placeholder="Carpet Area">

                </div>
				<div class="form-group">

                  <label>Photo</label>

                  <input type="file" class="form-control" id="" name="photo">
				  <img src="<?php echo $photo; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo;?>" name="oldpic" required>
<input type="text" class="form-control" id="" value="<?php echo $phototitle;?>" name="phototitle" >



                </div>
				<div class="form-group">

                  <label>Photo 2</label>

                  <input type="file" class="form-control" id="" name="photo2">
				  <img src="<?php echo $photo2; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo2;?>" name="oldpic2" required>
<input type="text" class="form-control" id="" value="<?php echo $photo2title;?>" name="photo2title" >



                </div>
				<div class="form-group">

                  <label>Photo 3</label>

                  <input type="file" class="form-control" id="" name="photo3">
				  <img src="<?php echo $photo3; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo3;?>" name="oldpic3" required>
<input type="text" class="form-control" id="" value="<?php echo $photo3title;?>" name="photo3title" >



                </div>
				<div class="form-group">

                  <label>Photo 4</label>

                  <input type="file" class="form-control" id="" name="photo4">
				  <img src="<?php echo $photo4; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo4;?>" name="oldpic4" required>

<input type="text" class="form-control" id="" value="<?php echo $photo4title;?>" name="photo4title" >


                </div>
				
					<div class="form-group">

                  <label>Photo 5</label>

                  <input type="file" class="form-control" id="" name="photo5">
				  <img src="<?php echo $photo5; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo5;?>" name="oldpic5" required>
<input type="text" class="form-control" id="" value="<?php echo $photo5title;?>" name="photo5title" >



                </div>
				<div class="form-group">

                  <label>Photo 6</label>

                  <input type="file" class="form-control" id="" name="photo6">
				  <img src="<?php echo $photo6; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo6;?>" name="oldpic6" required>
<input type="text" class="form-control" id="" value="<?php echo $photo6title;?>" name="photo6title" >



                </div>
				<div class="form-group">

                  <label>Photo 7</label>

                  <input type="file" class="form-control" id="" name="photo7">
				  <img src="<?php echo $photo7; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo7;?>" name="oldpic7" required>
<input type="text" class="form-control" id="" value="<?php echo $photo7title;?>" name="photo7title" >



                </div>
				<div class="form-group">

                  <label>Photo 8</label>

                  <input type="file" class="form-control" id="" name="photo8">
				  <img src="<?php echo $photo8; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo8;?>" name="oldpic8" required>
<input type="text" class="form-control" id="" value="<?php echo $photo8title;?>" name="photo8title" >



                </div>
				<div class="form-group">

                  <label>Photo 9</label>

                  <input type="file" class="form-control" id="" name="photo9">
				  <img src="<?php echo $photo9; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo9;?>" name="oldpic9" required>
<input type="text" class="form-control" id="" value="<?php echo $photo9title;?>" name="photo9title" >



                </div>
				<div class="form-group">

                  <label>Photo 10</label>

                  <input type="file" class="form-control" id="" name="photo10">
				  <img src="<?php echo $photo10; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo10;?>" name="oldpic10" required>
<input type="text" class="form-control" id="" value="<?php echo $photo10title;?>" name="photo10title" >



                </div>
				<div class="form-group">

                  <label>Photo 11</label>

                  <input type="file" class="form-control" id="" name="photo11">
				  <img src="<?php echo $photo11; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo11;?>" name="oldpic11" required>
<input type="text" class="form-control" id="" value="<?php echo $photo11title;?>" name="photo11title" >



                </div>
				<div class="form-group">

                  <label>Photo 12</label>

                  <input type="file" class="form-control" id="" name="photo12">
				  <img src="<?php echo $photo12; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo12;?>" name="oldpic12" required>
<input type="text" class="form-control" id="" value="<?php echo $photo12title;?>" name="photo12title" >



                </div>
				<div class="form-group">

                  <label>Photo 13</label>

                  <input type="file" class="form-control" id="" name="photo13">
				  <img src="<?php echo $photo13; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo13;?>" name="oldpic13" required>
<input type="text" class="form-control" id="" value="<?php echo $photo13title;?>" name="photo13title" >



                </div>
				<div class="form-group">

                  <label>Photo 14</label>

                  <input type="file" class="form-control" id="" name="photo14">
				  <img src="<?php echo $photo14; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo14;?>" name="oldpic14" required>
<input type="text" class="form-control" id="" value="<?php echo $photo14title;?>" name="photo14title" >



                </div>
				<div class="form-group">

                  <label>Photo 15</label>

                  <input type="file" class="form-control" id="" name="photo15">
				  <img src="<?php echo $photo15; ?>" style="width:60px;">
<input type="hidden" class="form-control" id="" value="<?php echo $photo15;?>" name="oldpic15" required>
<input type="text" class="form-control" id="" value="<?php echo $photo15title;?>" name="photo15title" >



                </div>
				
<div class="form-group">

                  <label>Description</label>

 <textarea type="text" class="form-control"  name="description" placeholder="Description">
 <?php echo $description; ?>
</textarea>
                </div>

<style>
.form-group b{
	padding-bottom:10px !important;
}
.modal-content .col-md-6,.modal-content .col-md-12{
	padding:0;
}
</style>

						<!--<div class="form-group col-md-6">
							<b>Select State</b><br>
							<select class="sel" id="state_id" name="state_id" required="">
								<option value="<?php echo $rr['state_id'];?>"><?php echo $fetchs['name'];?></option>
								<?php 
								
								$sc = mysql_query("select * from states where country_id='105'");
								while($fs= mysql_fetch_array($sc)){
									extract($fs);
									?>
										<option value="<?php echo $id;?>"><?php echo $name;?></option>
									<?php
								}?>
							</select>
						</div>
						<div class="form-group col-md-6">
							<b>Select City</b><br>
							<select class="sel" name="city_id" id="city_id" required="">
								<option value="<?php echo $rr['city_id'];?>"><?php echo $fetchc['city'];?></option>
								
							</select>
						</div>-->
						<div class="form-group">

                  <label>Area/Sub-Location</label>

                 
<select name="sub_location" class="form-control">
		<option><?php echo $sub_location; ?></option>
		<option>Airoli East</option>
		<option>Airoli West</option>
		<option>Ambarnath East</option>
		<option>Ambernath West</option>
		<option>Ambewadi</option>
		<option>Amboli</option>
		<option>Andheri</option>
		<option>Antop hill</option>
		<option>Apollo bunder</option>
		<option>Badlapur East</option>
		 <option>Badlapur West</option>
		<option>Bandra East</option>
		<option>Bandra West</option>
		<option>Belapur</option>
		<option>Bhandup East</option>
		<option>Bhandup West</option>
		<option>Bhayandar East</option>
		<option>Bhayandar West</option>
		<option>Bhiwandi</option>
		<option>Bhoiwada</option>
		<option>Boisar West</option>
		<option>Borivali</option>
		<option>Byculla East</option>
		<option>Byculla West</option>
		<option>Cbd belapur sector 11</option>
		<option>Chandivali</option>
		<option>Chembur East</option>
		<option>Chembur West</option>
		<option>Chinchpokli East</option>
		<option>Chinchpokli West</option>
		<option>Churchgate</option>
		<option>Borivali East</option>
		<option>Khar East  </option>
		<option>Khar West</option>
	  <option>Juhu</option>
	  <option>Carter Road</option>
	  <option>Worli East</option>
	  <option>Worli West</option>
	  <option>Mahim East</option>
	  <option>Mahim West</option>
	  <option>Matunga East</option>
	  <option>Matunga </option>
		<option>Santacruz East</option>
		<option>Santacruz West</option>
		
    <option><font alt="dadar-West.html">Dadar East</font></option>
    <option><font alt="dadar-West.html">Dadar West</font></option>
    <option><font alt="dahisar-East.html">Dahisar East</font></option>
    <option><font alt="dahisar-West.html">Dahisar West</font></option>
    <option><font alt="dana-bunder.html">Dana bunder</font></option>
    <option><font alt="danda.html">Danda</font></option>
    <option><font alt="deonar.html">Deonar</font></option>
    <option><font alt="deonar-East.html">Deonar East</font></option>
    <option><font alt="dharavi.html">Dharavi</font></option>
    <option><font alt="dhobhi-talao.html">Dhobhi talao</font></option>
    <option><font alt="dhobi-talao.html">Dhobi talao</font></option>
    <option><font alt="dombivali.html">Dombivali</font></option>
    <option><font alt="dombivali-East.html">Dombivali East</font></option>
    <option><font alt="dombivali-West.html">Dombivali West</font></option>
    <option><font alt="fort.html">Fort</font></option>
    <option><font alt="gamdevi.html">Gamdevi</font></option>
    <option><font alt="ghansoli.html">Ghansoli</font></option>
    <option><font alt="ghatkopar.html">Ghatkopar</font></option>
    <option><font alt="ghatkopar-East.html">Ghatkopar East</font></option>
    <option><font alt="ghatkopar-West.html">Ghatkopar West</font></option>
    <option><font alt="girgaon.html">Girgaon</font></option>
    <option><font alt="girgaon-chowpatty.html">Girgaon chowpatty</font></option>
    <option><font alt="goregaon-East.html">Goregaon East</font></option>
    <option><font alt="goregaon-West.html">Goregaon West</font></option>
    <option><font alt="goregoan.html">Goregoan</font></option>
    <option><font alt="govandi.html">Govandi</font></option>
    <option><font alt="govandi-East.html">Govandi East</font></option>
    <option><font alt="govandi-West.html">Govandi West</font></option>
    <option><font alt="government-colony.html">Government colony</font></option>
    <option><font alt="gowalia-tank.html">Gowalia tank</font></option>
    <option><font alt="grant-road.html">Grant road</font></option>
    <option><font alt="grant-road-East.html">Grant road East</font></option>
    <option><font alt="grant-road-West.html">Grant road West</font></option>
    <option><font alt="green-park-extension.html">Green park extension</font></option>
    <option><font alt="irla.html">Irla</font></option>
    <option><font alt="j-b-nagar.html">J b nagar</font></option>
    <option><font alt="jacob-circle.html">Jacob circle</font></option>
    <option><font alt="jogeshwari.html">Jogeshwari</font></option>
    <option><font alt="jogeshwari-East.html">Jogeshwari East</font></option>
    <option><font alt="jogeshwari-West.html">Jogeshwari West</font></option>
    <option><font alt="juhu.html">Juhu</font></option>
    <option><font alt="juhu-scheme.html">Juhu scheme</font></option>
    <option><font alt="kala-ghoda.html">Kala ghoda</font></option>
    <option><font alt="kalamboli.html">Kalamboli</font></option>
    <option><font alt="kalbadevi.html">Kalbadevi</font></option>
    <option><font alt="kalwa.html">Kalwa</font></option>
    <option><font alt="kalwa-West.html">Kalwa West</font></option>
    <option><font alt="kalyan.html">Kalyan</font></option>
    <option><font alt="kalyan-East.html">Kalyan East</font></option>
    <option><font alt="kalyan-West.html">Kalyan West</font></option>
    <option><font alt="kamothe.html">Kamothe</font></option>
    <option><font alt="kandivali.html">Kandivali</font></option>
    <option><font alt="kandivali-East.html">Kandivali East</font></option>
    <option><font alt="colaba.html">Colaba</font></option>
<option><font alt="kandivali-west.html">Kandivali west</font></option>
<option><font alt="kanjur-marg-east.html">Kanjur marg east</font></option>
<option><font alt="kanjur-marg-west.html">Kanjur marg west</font></option>
<option><font alt="kanjurmarg.html">Kanjurmarg</font></option>
<option><font alt="kanjurmarg-east.html">Kanjurmarg east</font></option>
<option><font alt="kanjurmarg-west.html">Kanjurmarg west</font></option>
<option><font alt="kemps-corner.html">Kemps corner</font></option>
<option><font alt="ketkipada.html">Ketkipada</font></option>
<option><font alt="khar.html">Khar</font></option>
<option><font alt="khar-danda.html">Khar danda</font></option>
<option><font alt="khar-east.html">Khar east</font></option>
<option><font alt="khar-west.html">Khar west</font></option>
<option><font alt="kharghar.html">Kharghar</font></option>
<option><font alt="kharghar-sector-12.html">Kharghar sector 12</font></option>
<option><font alt="kharghar-sector-2.html">Kharghar sector 2</font></option>
<option><font alt="kharghar-sector-7.html">Kharghar sector 7</font></option>
<option><font alt="khetwadi.html">Khetwadi</font></option>
<option><font alt="khopoli.html">Khopoli</font></option>
<option><font alt="kidwai-nagar.html">Kidwai nagar</font></option>
<option><font alt="kopar-khairane.html">Kopar khairane</font></option>
<option><font alt="kurla-east.html">Kurla east</font></option>
<option><font alt="kurla-west.html">Kurla west</font></option>
<option><font alt="lal-baug.html">Lal baug</font></option>
<option><font alt="lohar-chawl.html">Lohar chawl</font></option>
<option><font alt="lokhandwala.html">Lokhandwala</font></option>
<option><font alt="lower-parel-east.html">Lower parel east</font></option>
<option><font alt="lower-parel-west.html">Lower parel west</font></option>
<option><font alt="mahalaxmi.html">Mahalaxmi</font></option>
<option><font alt="mahape.html">Mahape</font></option>
<option><font alt="mahim.html">Mahim</font></option>
<option><font alt="mahim-east.html">Mahim east</font></option>
<option><font alt="mahim-west.html">Mahim west</font></option>
<option><font alt="malabar-hill.html">Malabar hill</font></option>
<option><font alt="malad.html">Malad</font></option>
<option><font alt="malad-west.html">Malad west</font></option>
<option><font alt="marine-lines.html">Marine lines</font></option>
<option><font alt="mazagaon.html">Mazagaon</font></option>
<option><font alt="naigaon.html">Naigaon</font></option>
<option><font alt="navi-mumbai.html">Navi mumbai</font></option>
<option><font alt="oshiwara.html">Oshiwara</font></option>
<option><font alt="panvel.html">Panvel</font></option>
<option><font alt="parel.html">Parel</font></option>
<option><font alt="prabhadevi.html">Prabhadevi</font></option>
<option><font alt="santacruz.html">Santacruz</font></option>
<option><font alt="seepz.html">Seepz</font></option>
<option><font alt="tardeo.html">Tardeo</font></option>
<option><font alt="thakurdwar.html">Thakurdwar</font></option>
<option><font alt="vakola.html">Vakola</font></option>
<option><font alt="vesava.html">Vesava</font></option>
	  <option>Vile Parle East</option>
	  <option>Vile Parle West</option>
<option><font alt="wadala.html">Wadala</font></option>
<option><font alt="worli.html ">Worli</font></option>
<option><font alt="borivali-west.html">Borivali West</font></option>
<option><font alt="andheri-east.html">Andheri East</font></option>
<option><font alt="andheri-west.html">Andheri West</font></option>
</select>



                </div>
				
						<div class="form-group col-md-6">
							<b id="">Property type</b><br>
							<select class="sel" name="category" required="">
								<option value="<?php echo $rr['category'];?>"><?php echo $rr['category'];?></option>
								<option value="Residential">Residential</option>
								<option value="Commercial">Commercial</option>
							</select>
						</div>
						<div class="form-group col-md-6">
							<b id="">Possession type</b><br>
							<select class="sel" name="possession_type" required="">
								<option value="<?php echo $rr['possession_type'];?>"><?php echo $rr['possession_type'];?></option>
								<option value="Under Construction">Under Construction</option>
								<option value="Ready to Move">Ready to Move</option>
								<option value="Lease/Rent">Lease/Rent</option>
							</select>
						</div>
						<div class="form-group col-md-6">
							<b>Typology</b><br>
							<select class="sel" name="property_type" required="">
								<option value="<?php echo $rr['property_type'];?>"><?php echo $rr['property_type'];?></option>
								<option value="1BHK">1BHK</option>
								<option value="2BHK">2BHK</option>
								<option value="3BHK">3BHK</option>
								<option value="4BHK">4BHK</option>
								<option value="5BHK">5BHK</option>
							</select>
						</div>
<div class="form-group col-md-12">
							<b>Purchase Type</b><br>
							<select class="sel" name="purchase_type" required="">
								<option><?php echo $purchase_type;?></option>
								<option value="For Rent">For Rent</option>
								<option value="For Sale">For Sale</option>
								
							</select>
						</div>

<div class="clearfix"></div>

<div class="box-footer">

                <button type="submit" name="update" class="btn btn-primary">Update</button> <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        

              </div>

                

              </div>



</form>



        </div>

       

      

    </div>

  </div>

  

</div>



<?php

}





?>

<!--add new start-->

<!-- Modal -->

  <div class="modal fade" id="myModal" role="dialog">

    <div class="modal-dialog">

    

      <!-- Modal content-->

      <div class="modal-content">

        <div class="modal-header">

          <button type="button" class="close" data-dismiss="modal">&times;</button>

          <h4 class="modal-title">Add New Property</h4>

        </div>

        <div class="modal-body">

          <form method="post" action="" enctype="multipart/form-data">

<div class="box-body" style="width:70%">

                <div class="form-group">

                  <label>Property Name</label>

                  <input type="text" class="form-control" id="" name="name" placeholder="Name" required>



                </div>  
				
				<div class="form-group">

                  <label>Property Price/Rent</label>

                  <input type="text" class="form-control" value="" id="no" name="price" placeholder="Price/Rent">

                </div>
				<div class="form-group">

                  <label>Built up Area(sqft)</label>

                  <input type="text" class="form-control" value="" id="no" name="builtup_area" placeholder="Built Up Area">

                </div>
				<div class="form-group">

                  <label>Carpet Area(sqft)</label>

                  <input type="text" class="form-control" value="" id="no" name="carpet_area" placeholder="Carpet Area">

                </div>
				<div class="form-group">

                  <label>Photo</label>

                  <input type="file" class="form-control" id="" name="photo" required>
<input type="text" class="form-control" id="" name="phototitle" placeholder="phototitle" required>



                </div>
				<div class="form-group">

                  <label>Photo 2</label>

                  <input type="file" class="form-control" id="" name="photo2" >
<input type="text" class="form-control" id="" name="photo2title" placeholder="phototitle" required>



                </div>
				<div class="form-group">

                  <label>Photo 3</label>
<input type="text" class="form-control" id="" name="photo3title" placeholder="phototitle" required>

                  <input type="file" class="form-control" id="" name="photo3" >



                </div>
				<div class="form-group">

                  <label>Photo 4</label>

                  <input type="file" class="form-control" id="" name="photo4" >
<input type="text" class="form-control" id="" name="photo4title" placeholder="phototitle" required>



                </div>
			
<div class="form-group">

                  <label>Photo 5</label>

                  <input type="file" class="form-control" id="" name="photo5" >
<input type="text" class="form-control" id="" name="photo5title" placeholder="phototitle" required>



                </div>
				<div class="form-group">

                  <label>Photo 6</label>

                  <input type="file" class="form-control" id="" name="photo6" >
<input type="text" class="form-control" id="" name="photo6title" placeholder="phototitle" required>



                </div>
			<div class="form-group">

                  <label>Photo 7</label>

                  <input type="file" class="form-control" id="" name="photo7" >
<input type="text" class="form-control" id="" name="photo7title" placeholder="phototitle" required>



                </div>
			
					<div class="form-group">

                  <label>Photo 8</label>

                  <input type="file" class="form-control" id="" name="photo8" >
<input type="text" class="form-control" id="" name="photo8title" placeholder="phototitle" required>



                </div>
				
				<div class="form-group">

                  <label>Photo 9</label>

                  <input type="file" class="form-control" id="" name="photo9" >
<input type="text" class="form-control" id="" name="photo9title" placeholder="phototitle" required>



                </div>
				
				<div class="form-group">

                  <label>Photo 10</label>

                  <input type="file" class="form-control" id="" name="photo10" >
<input type="text" class="form-control" id="" name="photo10title" placeholder="phototitle" required>



                </div>
				<div class="form-group">

                  <label>Photo 11</label>

                  <input type="file" class="form-control" id="" name="photo11" >
<input type="text" class="form-control" id="" name="photo11title" placeholder="phototitle" required>



                </div>
				<div class="form-group">

                  <label>Photo 12</label>

                  <input type="file" class="form-control" id="" name="photo12" >
<input type="text" class="form-control" id="" name="photo12title" placeholder="phototitle" required>



                </div>
				<div class="form-group">

                  <label>Photo 13</label>

                  <input type="file" class="form-control" id="" name="photo13" >
<input type="text" class="form-control" id="" name="photo13title" placeholder="phototitle" required>



                </div>
				
				<div class="form-group">

                  <label>Photo 14</label>

                  <input type="file" class="form-control" id="" name="photo14" >
<input type="text" class="form-control" id="" name="photo14title" placeholder="phototitle" required>



                </div>
				<div class="form-group">

                  <label>Photo 15</label>

                  <input type="file" class="form-control" id="" name="photo15" >
<input type="text" class="form-control" id="" name="photo15title" placeholder="phototitle" required>



                </div>
			
			
			
			
			
			
			
				
				

<div class="form-group">

                  <label>Description</label>

 <textarea type="text" class="form-control"  name="description" placeholder="Description">

</textarea>
                </div>
				
				<script type="text/javascript">
  $(document).ready(function(){ /* PREPARE THE SCRIPT */
    $("#state_id").change(function(){ /* WHEN YOU CHANGE AND SELECT FROM THE SELECT FIELD */
      var state_id = $(this).val(); /* GET THE VALUE OF THE SELECTED DATA */
      var dataString = "state_id="+state_id; /* STORE THAT TO A DATA STRING */

      $.ajax({ /* THEN THE AJAX CALL */
        type: "POST", /* TYPE OF METHOD TO USE TO PASS THE DATA */
        url: "get_cities.php", /* PAGE WHERE WE WILL PASS THE DATA */
        data: dataString, /* THE DATA WE WILL BE PASSING */
        success: function(result){ /* GET THE TO BE RETURNED DATA */
          $("#city_id").html(result); /* THE RETURNED DATA WILL BE SHOWN IN THIS DIV */
        }
      });

    });
  });
  
</script>
<style>
.form-group b{
	padding-bottom:10px !important;
}
.modal-content .col-md-6,.modal-content .col-md-12{
	padding:0;
}
</style>
<!--
<div class="form-group col-md-6">
							<b>Select State</b><br>
							<select class="sel" id="state_id2" name="state_id" required="">
								<option value="">Select State</option>
								<?php 
								
								$sc = mysql_query("select * from states where country_id='105'");
								while($fs= mysql_fetch_array($sc)){
									extract($fs);
									?>
										<option value="<?php echo $id;?>"><?php echo $name;?></option>
									<?php
								}?>
							</select>
						</div>
						<div class="form-group col-md-6">
							<b>Select City</b><br>
							<select class="sel" name="city_id" id="city_id2" required="">
								<option value="">Select City</option>
								
							</select>
						</div>
						-->
						<div class="form-group">

                  <label>Area/Sub-Location</label>

                  <select name="sub-location" class="form-control">
		<option>Airoli East</option>
		<option>Airoli West</option>
		<option>Ambarnath East</option>
		<option>Ambernath West</option>
		<option>Ambewadi</option>
		<option>Amboli</option>
		<option>Andheri</option>
		<option>Antop hill</option>
		<option>Apollo bunder</option>
		<option>Badlapur East</option>
		 <option>Badlapur West</option>
		<option>Bandra East</option>
		<option>Bandra West</option>
		<option>Belapur</option>
		<option>Bhandup East</option>
		<option>Bhandup West</option>
		<option>Bhayandar East</option>
		<option>Bhayandar West</option>
		<option>Bhiwandi</option>
		<option>Bhoiwada</option>
		<option>Boisar West</option>
		<option>Borivali</option>
		<option>Byculla East</option>
		<option>Byculla West</option>
		<option>Cbd belapur sector 11</option>
		<option>Chandivali</option>
		<option>Chembur East</option>
		<option>Chembur West</option>
		<option>Chinchpokli East</option>
		<option>Chinchpokli West</option>
		<option>Churchgate</option>
		<option>Borivali East</option>
		<option>Khar East  </option>
		<option>Khar West</option>
	  <option>Juhu</option>
	  <option>Carter Road</option>
	  <option selected>Worli East</option>
	  <option>Worli West</option>
	  <option>Mahim East</option>
	  <option>Mahim West</option>
	  <option>Matunga East</option>
	  <option>Matunga </option>
		<option>Santacruz East</option>
		<option>Santacruz West</option>
		
    <option><font alt="dadar-West.html">Dadar East</font></option>
    <option><font alt="dadar-West.html">Dadar West</font></option>
    <option><font alt="dahisar-East.html">Dahisar East</font></option>
    <option><font alt="dahisar-West.html">Dahisar West</font></option>
    <option><font alt="dana-bunder.html">Dana bunder</font></option>
    <option><font alt="danda.html">Danda</font></option>
    <option><font alt="deonar.html">Deonar</font></option>
    <option><font alt="deonar-East.html">Deonar East</font></option>
    <option><font alt="dharavi.html">Dharavi</font></option>
    <option><font alt="dhobhi-talao.html">Dhobhi talao</font></option>
    <option><font alt="dhobi-talao.html">Dhobi talao</font></option>
    <option><font alt="dombivali.html">Dombivali</font></option>
    <option><font alt="dombivali-East.html">Dombivali East</font></option>
    <option><font alt="dombivali-West.html">Dombivali West</font></option>
    <option><font alt="fort.html">Fort</font></option>
    <option><font alt="gamdevi.html">Gamdevi</font></option>
    <option><font alt="ghansoli.html">Ghansoli</font></option>
    <option><font alt="ghatkopar.html">Ghatkopar</font></option>
    <option><font alt="ghatkopar-East.html">Ghatkopar East</font></option>
    <option><font alt="ghatkopar-West.html">Ghatkopar West</font></option>
    <option><font alt="girgaon.html">Girgaon</font></option>
    <option><font alt="girgaon-chowpatty.html">Girgaon chowpatty</font></option>
    <option><font alt="goregaon-East.html">Goregaon East</font></option>
    <option><font alt="goregaon-West.html">Goregaon West</font></option>
    <option><font alt="goregoan.html">Goregoan</font></option>
    <option><font alt="govandi.html">Govandi</font></option>
    <option><font alt="govandi-East.html">Govandi East</font></option>
    <option><font alt="govandi-West.html">Govandi West</font></option>
    <option><font alt="government-colony.html">Government colony</font></option>
    <option><font alt="gowalia-tank.html">Gowalia tank</font></option>
    <option><font alt="grant-road.html">Grant road</font></option>
    <option><font alt="grant-road-East.html">Grant road East</font></option>
    <option><font alt="grant-road-West.html">Grant road West</font></option>
    <option><font alt="green-park-extension.html">Green park extension</font></option>
    <option><font alt="irla.html">Irla</font></option>
    <option><font alt="j-b-nagar.html">J b nagar</font></option>
    <option><font alt="jacob-circle.html">Jacob circle</font></option>
    <option><font alt="jogeshwari.html">Jogeshwari</font></option>
    <option><font alt="jogeshwari-East.html">Jogeshwari East</font></option>
    <option><font alt="jogeshwari-West.html">Jogeshwari West</font></option>
    <option><font alt="juhu.html">Juhu</font></option>
    <option><font alt="juhu-scheme.html">Juhu scheme</font></option>
    <option><font alt="kala-ghoda.html">Kala ghoda</font></option>
    <option><font alt="kalamboli.html">Kalamboli</font></option>
    <option><font alt="kalbadevi.html">Kalbadevi</font></option>
    <option><font alt="kalwa.html">Kalwa</font></option>
    <option><font alt="kalwa-West.html">Kalwa West</font></option>
    <option><font alt="kalyan.html">Kalyan</font></option>
    <option><font alt="kalyan-East.html">Kalyan East</font></option>
    <option><font alt="kalyan-West.html">Kalyan West</font></option>
    <option><font alt="kamothe.html">Kamothe</font></option>
    <option><font alt="kandivali.html">Kandivali</font></option>
    <option><font alt="kandivali-East.html">Kandivali East</font></option>
    <option><font alt="colaba.html">Colaba</font></option>
<option><font alt="kandivali-west.html">Kandivali west</font></option>
<option><font alt="kanjur-marg-east.html">Kanjur marg east</font></option>
<option><font alt="kanjur-marg-west.html">Kanjur marg west</font></option>
<option><font alt="kanjurmarg.html">Kanjurmarg</font></option>
<option><font alt="kanjurmarg-east.html">Kanjurmarg east</font></option>
<option><font alt="kanjurmarg-west.html">Kanjurmarg west</font></option>
<option><font alt="kemps-corner.html">Kemps corner</font></option>
<option><font alt="ketkipada.html">Ketkipada</font></option>
<option><font alt="khar.html">Khar</font></option>
<option><font alt="khar-danda.html">Khar danda</font></option>
<option><font alt="khar-east.html">Khar east</font></option>
<option><font alt="khar-west.html">Khar west</font></option>
<option><font alt="kharghar.html">Kharghar</font></option>
<option><font alt="kharghar-sector-12.html">Kharghar sector 12</font></option>
<option><font alt="kharghar-sector-2.html">Kharghar sector 2</font></option>
<option><font alt="kharghar-sector-7.html">Kharghar sector 7</font></option>
<option><font alt="khetwadi.html">Khetwadi</font></option>
<option><font alt="khopoli.html">Khopoli</font></option>
<option><font alt="kidwai-nagar.html">Kidwai nagar</font></option>
<option><font alt="kopar-khairane.html">Kopar khairane</font></option>
<option><font alt="kurla-east.html">Kurla east</font></option>
<option><font alt="kurla-west.html">Kurla west</font></option>
<option><font alt="lal-baug.html">Lal baug</font></option>
<option><font alt="lohar-chawl.html">Lohar chawl</font></option>
<option><font alt="lokhandwala.html">Lokhandwala</font></option>
<option><font alt="lower-parel-east.html">Lower parel east</font></option>
<option><font alt="lower-parel-west.html">Lower parel west</font></option>
<option><font alt="mahalaxmi.html">Mahalaxmi</font></option>
<option><font alt="mahape.html">Mahape</font></option>
<option><font alt="mahim.html">Mahim</font></option>
<option><font alt="mahim-east.html">Mahim east</font></option>
<option><font alt="mahim-west.html">Mahim west</font></option>
<option><font alt="malabar-hill.html">Malabar hill</font></option>
<option><font alt="malad.html">Malad</font></option>
<option><font alt="malad-west.html">Malad west</font></option>
<option><font alt="marine-lines.html">Marine lines</font></option>
<option><font alt="mazagaon.html">Mazagaon</font></option>
<option><font alt="naigaon.html">Naigaon</font></option>
<option><font alt="navi-mumbai.html">Navi mumbai</font></option>
<option><font alt="oshiwara.html">Oshiwara</font></option>
<option><font alt="panvel.html">Panvel</font></option>
<option><font alt="parel.html">Parel</font></option>
<option><font alt="prabhadevi.html">Prabhadevi</font></option>
<option><font alt="santacruz.html">Santacruz</font></option>
<option><font alt="seepz.html">Seepz</font></option>
<option><font alt="tardeo.html">Tardeo</font></option>
<option><font alt="thakurdwar.html">Thakurdwar</font></option>
<option><font alt="vakola.html">Vakola</font></option>
<option><font alt="vesava.html">Vesava</font></option>
	  <option>Vile Parle East</option>
	  <option>Vile Parle West</option>
<option><font alt="wadala.html">Wadala</font></option>
<option><font alt="worli.html ">Worli</font></option>
<option><font alt="borivali-west.html">Borivali West</font></option>
<option><font alt="andheri-east.html">Andheri East</font></option>
<option><font alt="andheri-west.html">Andheri West</font></option>
</select>




                </div>
						<div class="form-group col-md-6">
							<b id="">Property type</b><br>
							<select class="sel" name="category" required="">
								<option value="">Select</option>
								<option value="Residential">Residential</option>
								<option value="Commercial">Commercial</option>
							</select>
						</div>
						<div class="form-group col-md-6">
							<b id="">Possession type</b><br>
							<select class="sel" name="possession_type" required="">
								<option value="">Select</option>
								<option value="Under Construction">Under Construction</option>
								<option value="Ready to Move">Ready to Move</option>
								<option value="Lease/Rent">Lease/Rent</option>
							</select>
						</div>
						
						<div class="form-group col-md-6">
							<b>Typology</b><br>
							<select class="sel" name="property_type" required="">
								<option value="">BHK</option>
								<option value="1BHK">1BHK</option>
								<option value="2BHK">2BHK</option>
								<option value="3BHK">3BHK</option>
								<option value="4BHK">4BHK</option>
								<option value="5BHK">5BHK</option>
							</select>
						</div>
<div class="form-group col-md-12">
							<b>Purchase Type</b><br>
							<select class="sel" name="purchase_type" required="">
								<option value="">Select</option>
								<option value="For Rent">For Rent</option>
								<option value="For Sale">For Sale</option>
								
							</select>
						</div>

<div class="clearfix"></div>
             <div class="box-footer">

                <button type="submit" name="submit" class="btn btn-primary">Submit</button>

              </div>

                

              </div>



</form>



        </div>

        <div class="modal-footer">

          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        </div>

      

      

    </div>

  </div>



</div>







<!--add new end-->

























































<?php include('footer.php');?>