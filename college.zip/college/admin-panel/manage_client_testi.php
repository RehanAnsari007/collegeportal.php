<?php 
include('header2.php');
include('datatable.php');
if(isset($_REQUEST['actid'])){
$actid=$_REQUEST['actid'];
$select=mysql_query("update testi set status='1' where id='$actid'");
if($select){
?>
<script>alert("testimonial activated..!");</script>
<?php
}
}
//add
if(isset($_POST['add'])){
$descff=mysql_real_escape_string($_POST['descff']);

$byrr=mysql_real_escape_string($_POST['byrr']);


$insert=mysql_query("insert into testi(descff,byrr) values('$descff','$byrr')");
if($insert){
?>
<script>alert('Testimonial Added !');</script>
<?php
}
else{
?>
<script>alert('Details Not Added !');</script>
<?php
}

}
//add end
//update
if(isset($_POST['update'])){
$descff=mysql_real_escape_string($_POST['descff']);

$byrr=mysql_real_escape_string($_POST['byrr']);
$oid=mysql_real_escape_string($_POST['oid']);


$insert=mysql_query("update testi set descff='$descff',byrr='$byrr' where id='$oid'");
if($insert){
?>
<script>alert('Updated ! ');</script>
<?php
}
else{
?>
<script>alert('  Details Not Updated ! ');</script>
<?php
}

}
//update end
//delete start
if(isset($_GET['did'])){
$did=$_GET['did'];



$insert=mysql_query("delete from testi where id='$did'");
if($insert){
?>
<script>alert(' Details Deleted ! ');
</script>
<?php
}
else{
?>
<script>alert('  Details Not Deleted ! ');</script>
<?php
}

}
//delete end
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
<div class="content">

<div class="title"><br>
<h3 style="margin:10px;color:gray">Testimonials</h3><hr>
</div>
<button type="button" data-toggle="modal" class="btn btn-primary" data-target="#myModaladd"><i class="fa fa-plus-circle" aria-hidden="true"></i>&nbsp;Add New Testimonials
</button>



 <div class="box">
            <div class="box-header">
        <!--     
<img src="pdf.png" id="cms" style="width:30px;height:30px;cursor:pointer"/>

<a href="party_excel.php"><img src="excel.png" style="width:30px;height:30px;"/></a>

<img src="printer.png" onclick="PrintDiv();" style="width:30px;height:30px;cursor:pointer"/>
-->

            </div>
            <!-- /.box-header -->
            <div class="box-body" id="print">
              <table id="example1" class="table table-bordered table-striped" style="width:100%;">
                <thead>
               <tr>
                   <th>S.no.</th>
                  <th>Description</th>
                  <th>By</th>
                 
                  <th>Delete</th>
                  <th>Update</th>
                  <th>Activate</th>
                </tr>
                </thead>
                <tbody>
<?php
$rr=mysql_query("SELECT * from testi where status='0' order by id desc");
$nr=0;
while($rrr=mysql_fetch_array($rr))
{
$nr++;
$descff=$rrr['descff'];
$byrr=$rrr['byrr'];
$id=$rrr['id'];



?>
<tr>
<td><?php echo $nr; ?></td>
<td><?php echo $descff; ?></td>
<td><?php echo $byrr;?></td>
<td><a onclick="return confirm('are you sure to delete?')" href=manage_testi.php?did=<?php echo $id;?>><button><i class="fa fa-trash-o" aria-hidden="true"></i></button>
</a></font></td>


<td>

<!-- model open-->

<!-- Trigger the modal with a button -->
  <button type="button"  data-toggle="modal" data-target="#myModal<?php echo $nr;?>"><i class="fa fa-refresh" aria-hidden="true"></i>
</button>

<!-- model end-->

</td>
<td>
<button><a href='<?php echo $_SERVER['REQUEST_URI'];?>?actid=<?php echo $id;?>'>Activate</a></button>
</td>
</tr>
<?php
}
?>


</table>
<?php print_r($rrr);?>


</div>


</div>
</div>

<?php 
$nr=0;
$result1=mysql_query("SELECT * from testi where status ='0' order by id desc");

while($rr=mysql_fetch_array($result1))

{
$nr++;
?>

  <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $nr;?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update  Details</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="" enctype="multipart/form-data">
<div class="box-body" style="width:70%">

<div class="form-group">
                  <label> Description</label>
                  <textarea type="text" name="descff" class="form-control" required id="owner" placeholder="Description"> <?php echo $rr['descff'];?></textarea>
    
                </div>
               
                <div class="form-group">
                  <label>By</label>
                  <input type="text" name="byrr" value="<?php echo $rr['byrr'];?>" class="form-control" required id="owner" placeholder="By">
                </div>

<input type="hidden" class="form-control"  value="<?php echo $rr['id']; ?>"  name="oid">



<div class="box-footer">
                <button type="submit" name="update" class="btn btn-primary">Update</button>
              </div>
                
              </div>

</form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      
      
    </div>
  </div>
  
</div>

<?php
}


?>

 <!-- Modal -->
  <div class="modal fade" id="myModaladd" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Testimonial</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="" enctype="multipart/form-data">
<div class="box-body" style="width:70%">

<div class="form-group">
                  <label> Description</label>
                  <textarea type="text" name="descff" class="form-control" required id="owner" placeholder="Description"><?php echo $rr['descff'];?></textarea>
    
                </div>
               
                <div class="form-group">
                  <label>By</label>
                  <input type="text" name="byrr" value="<?php echo $rr['byrr'];?>" class="form-control" required id="owner" placeholder="By">
                </div>



<div class="box-footer">
                <button type="submit" name="add" class="btn btn-primary">Add Testimonial</button>
              </div>
                
              </div>

</form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      
      
    </div>
  </div>
  
</div>
<?php include('footer.php');?>
















