<?php 
include('header2.php');
include('datatable.php');
//update
if(isset($_POST['update'])){
$name=$_POST['name'];

$email=$_POST['email'];
$phone=$_POST['phone'];
$message=$_POST['message'];
$oid=$_POST['oid'];


$insert=mysql_query("update inquiry set name='$name',email='$email',phone='$phone',message='$message' where id='$oid'");
if($insert){
?>
<script>alert(' Details Updated ! ');</script>
<?php
}
else{
?>
<script>alert('  Details Not Updated ! ');</script>
<?php
}

}
//update end
//add
if(isset($_POST['add'])){
$name=$_POST['name'];

$email=$_POST['email'];
$phone=$_POST['phone'];
$message=$_POST['message'];


$insert=mysql_query("insert into inquiry(name,email,phone,message) values('$name','$email','$phone','$message')");
if($insert){
?>
<script>alert(' Details Added ! ');</script>
<?php
}
else{
?>
<script>alert('  Details Not Added ! ');</script>
<?php
}

}
//add end
//delete start
if(isset($_GET['did'])){
$did=$_GET['did'];



$insert=mysql_query("delete from inquiry where id='$did'");
if($insert){
?>
<script>alert(' Details Deleted ! ');
document.location="manage_inquiry.php";
</script>
<?php
}
else{
?>
<script>alert('  Details Not Deleted ! ');</script>
<?php
}

}
//delete end
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
<div class="content">

<div class="title"><br>
<h3 style="margin:10px;color:gray">Inquiries</h3><hr>
</div>




 <div class="box">
            <div class="box-header">
        <!--     
<img src="pdf.png" id="cms" style="width:30px;height:30px;cursor:pointer"/>

<a href="party_excel.php"><img src="excel.png" style="width:30px;height:30px;"/></a>

<img src="printer.png" onclick="PrintDiv();" style="width:30px;height:30px;cursor:pointer"/>
-->

            </div>
            <!-- /.box-header -->
            <div class="box-body" id="print">
              <table id="example1" class="table table-bordered table-striped" style="width:100%;">
                <thead>
               <tr>
                   <th>S.no.</th>
                  <th>Name</th>
                  <th>Email </th>
				<th>  Phone</th>
                  <th>Message</th>
                  <th>Delete</th>
               <!--   <th>Update</th>-->
                </tr>
                </thead>
                <tbody>
<?php
$rr=mysql_query("SELECT * from inquiry order by id desc");
$nr=0;
while($rrr=mysql_fetch_array($rr))
{
$nr++;
$name=$rrr['name'];
$email=$rrr['email'];
$phone=$rrr['phone'];
$message=$rrr['message'];
$id=$rrr['id'];



?>
<tr>
<td><?php echo $nr; ?></td>
<td><b>Name=</b><?php echo $name; ?></td>
<td><b>Email =</b><?php echo $email;?></td><td>
<b>Mobile =</b> <?php echo $phone;?></td>
<td><?php echo $message;?></td>

<td><a onclick="return confirm('are you sure to delete?')" href=manage_inquiry.php?did=<?php echo $id;?>><button><i class="fa fa-trash-o" aria-hidden="true"></i></button>
</a></font></td>


<!--<td>


  <button type="button"  data-toggle="modal" data-target="#myModal<?php echo $nr;?>"><i class="fa fa-refresh" aria-hidden="true"></i>
</button>


</td>-->
</tr>
<?php
}
?>


</table>
<?php print_r($rrr);?>


</div>


</div>
</div>

<?php 
$nr=0;
$result1=mysql_query("SELECT * from inquiry order by id desc");

while($rr=mysql_fetch_array($result1))

{
$nr++;
$aaaa=$rr['name'];
?>

  <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $nr;?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update  inquiries</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="" enctype="multipart/form-data">
<div class="box-body" style="width:70%">

<div class="form-group">
                  <label> Name</label>
                  <input type="text" name="name" value="<?php echo $rr['name'];?>" class="form-control" required id="owner" placeholder="name">
    
                </div>
                

                <div class="form-group">
                  <label>Email</label>
                  <input type="text" name="email" value="<?php echo $rr['email'];?>" class="form-control" required id="owner" placeholder="email">
                </div>
<div class="form-group">
                  <label>Phone</label>
                  <input type="text" name="phone" value="<?php echo $rr['phone'];?>" class="form-control" required id="owner" placeholder="phone">
                </div>
<div class="form-group">
                  <label>Message</label>
                  <input type="text" name="message" value="<?php echo $rr['message'];?>" class="form-control" required id="owner" placeholder="message">
                </div>
<input type="hidden" class="form-control"  value="<?php echo $rr['id']; ?>"  name="oid" placeholder="Label Size ">


<div class="box-footer">
                <button type="submit" name="update" class="btn btn-primary">Update</button>
              </div>
                
              </div>

</form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      
      
    </div>
  </div>
  
</div>

<?php
}


?>


<?php include('footer.php');?>

















