<?php
include('connection.php');
header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
header("Content-type:   application/x-msexcel; charset=utf-8");
header("Content-Disposition: attachment; filename=labeldetails.xls"); 
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: private",false);

?>
<h1>Label list</h1>
<table  border="2" style="color:;">
                <thead>
                <tr>
                  <th>S.no.</th>
                  <th>Party_Name</th>
                  <th>Label Size </th>
                  <th>No. Of Labels</th>

                 
                </tr>
                </thead>
                <tbody>
<?php
$result=mysql_query("SELECT * from Label order by id desc");
$nr=0;
while($res=mysql_fetch_array($result))

{
$nr++;
$aa=$res['party_name'];
$bb=$res['labelsize'];
$cc=$res['no_of_labels'];

?>
<tr><td><?php echo $nr;?></td><td><?php echo $aa;?></td><td><?php echo $bb;?></td><td><?php echo $cc;?></td>
</tr>
<?php
}
?>


</table>