<?php 
include('header2.php');
include('datatable.php');



//update service

if(isset($_POST['update'])){
$name=$_POST['name'];
$opid=$_POST['oid'];
$de=mysql_real_escape_string($_POST['description']);
//$categoryid=mysql_real_escape_string($_POST['categoryid']);



if (!is_uploaded_file($_FILES['pic']['tmp_name'])) 
	{	
		$p1=$_POST['oldpic'];
         }
	else
	{ 
	

$thumb=basename($_FILES["pic"]["name"]);
$tpath1=$_FILES["pic"]["tmp_name"];
 $path1="uploads/".$thumb;
$p1="$path1";

move_uploaded_file($tpath1,$path1);
		
	}



$insert=mysql_query("update works set name='$name',photo='$p1',description='$de'  where id='$opid'");
if($insert){
?>
<script>alert('Updated ! ');</script>
<?php
}
else{
?>
<script>alert('Not Updated ! ');</script>
<?php
}

}






// ends update
//add service

if(isset($_POST['submit'])){
$name=$_POST['name'];
$de=mysql_real_escape_string($_POST['description']);
//$categoryid=mysql_real_escape_string($_POST['categoryid']);

$thumb=basename($_FILES["pic"]["name"]);
$tpath1=$_FILES["pic"]["tmp_name"];
 $path1="uploads/".$thumb;
$p1="$path1";

move_uploaded_file($tpath1,$path1);

$insert=mysql_query("insert into works(name,photo,description) values('$name','$p1','$de')");
if($insert){
?>
<script>alert('added ! ');</script>
<?php
}
else{
?>
<script>alert('Not added ! ');</script>
<?php
}

}


if(isset($_REQUEST['did'])){
$did=$_REQUEST['did'];
$insert=mysql_query("delete from works where id='$did'");
if($insert){
?>
<script>document.location='manage_works.php';</script>
<?php
}
else{
?>
<script>
document.location='manage_works.php';
</script>

<?php
}

}
?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
<div class="content">

<div class="title"><br>
<h3 style="margin:10px;color:gray">Works</h3><hr>
</div>




 <div class="box">
            <div class="box-header">
              
<!--<img src="pdf.png" id="cms" style="width:30px;height:30px;cursor:pointer"/>

<a href="label_excel.php"><img src="excel.png" style="width:30px;height:30px;"/></a>

<img src="printer.png" onclick="PrintDiv();" style="width:30px;height:30px;cursor:pointer"/>-->
<!-- Trigger the modal with a button -->
  <button type="button"  data-toggle="modal" class="btn btn-primary" data-target="#myModal"><i class="fa fa-plus-circle" aria-hidden="true"></i>
&nbsp;Add New Service
</button>

            </div>
            <!-- /.box-header -->
            <div class="box-body" id="print">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>S.no.</th>
                  <th>Work name</th>
                  <th>Photo</th>
                  <th>Description</th>
                 <!-- <th>Category</th>-->
                  <th>Delete</th><th>Edit</th>
                </tr>
                </thead>
                <tbody>
<?php
$result=mysql_query("SELECT * from works order by id desc");
$nr=0;
while($res=mysql_fetch_array($result))

{
$nr++;
$name=$res['name'];
$photo=$res['photo'];
$description=$res['description'];
//$cid=$res['categoryid'];
//$sc= mysql_query("select name from category where id ='$cid'");
//$fsc= mysql_fetch_array($sc);
//$category = $fsc['name'];
$id=$res['id'];
$ide=$res['id'];

?>
<tr><td><?php echo $nr;?></td><td><?php echo $name;?></td><td><a href='<?php echo $photo;?>' target='_blank'><img src='<?php echo $photo;?>' style="width:100px;height:100px;"><a/></td><td><?php echo $description;?></td>



<td><a onclick="return confirm('are you sure to delete?')" href=manage_works.php?did=<?php echo $id;?>><button><i class="fa fa-trash-o" aria-hidden="true"></i></button>
</a></font></td>

<td>

<!-- model open-->

<!-- Trigger the modal with a button -->
  <button type="button"  data-toggle="modal"  data-target="#myModal<?php echo $nr;?>"><i class="fa fa-refresh" aria-hidden="true"></i> 
</button>

<!-- model end-->




</td>
</tr>
<?php
}
?>


</table>

</div>


</div>
</div>
<?php 
$nn=0;
$rrs=mysql_query("SELECT * from works order by id desc");
while($rr= mysql_fetch_array($rrs)){
$nn++;
$aaa=$rr['name'];
$photo=$rr['photo'];
$description=$rr['description'];
//$categodyid=$rr['categoryid'];
//$sc= mysql_query("select name from category where id ='$categodyid'");
//$fsc= mysql_fetch_array($sc);
//$category = $fsc['name'];
$id=$rr['id'];
?>

  <!-- Modal -->
  <div class="modal fade" id="myModal<?php echo $nn;?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Update Details</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="" enctype="multipart/form-data">
<div class="box-body" style="width:70%">
                

                

<input type="hidden" class="form-control"  value="<?php echo $id; ?>"  name="oid">
<input type="hidden" class="form-control"  value="<?php echo $photo; ?>"  name="oldpic">

                </div>
<div class="form-group">
 

                 <script src="ckeditor/ckeditor.js"></script>
        <script src="ckeditor/config.js"></script>
                  <label>Work Name</label>
                  <input type="text" class="form-control" id="" value="<?php echo $aaa; ?>" name="name" placeholder="Work Name" required>
 <label>Photo</label>
                  <input type="file" class="form-control" id="" name="pic" ><img src="<?php echo $photo;?>" style="width:30px;height:30px;"><br>
Description :  <textarea name="description" id="editom<?php echo $nn;?>"  rows="10" cols="130">
               <?php echo $description;?>
            </textarea>
            <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'editom<?php echo $nn;?>' );
            </script>
                </div>
                 </div>

<div class="box-footer">
                <button type="submit" name="update" class="btn btn-primary">Update</button>
           
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
   </div>
                
              </div>

</form>

        </div>
      
      
    </div>
  </div>
  
</div>

<?php
}


?>
<!--add new start-->
<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add New Work</h4>
        </div>
        <div class="modal-body">
          <form method="post" action="" enctype="multipart/form-data">
<div class="box-body" style="width:70%">
                <div class="form-group">
                <!--  <label>Category</label>
<?php include_once('connection.php');
        $result = mysql_query("SELECT * FROM category")or die("Invalid Query: " .mysql_query());
         echo '<select id="categoryid"  name="categoryid" required>';
          echo '<option value="">Select</option>';
          while ($row = mysql_fetch_assoc($result))
          {
             $id = $row['id'];
              $name = $row['name'];
           echo "<option value='$id'>$name</option>";
         }	
           echo '</select>';
          ?>
<br>-->

              
                 <script src="ckeditor/ckeditor.js"></script>
        <script src="ckeditor/config.js"></script>
                  <label>Work Name</label>
                  <input type="text" class="form-control" id=""  name="name" placeholder="Work Name" required>
 <label>Photo</label>
                  <input type="file" class="form-control" id="" name="pic" >
Description :  <textarea name="description" id="edi"  rows="10" cols="130">

            </textarea>
            <script>
                // Replace the <textarea id="editor1"> with a CKEditor
                // instance, using default configuration.
                CKEDITOR.replace( 'edi' );
            </script>
                </div>


             <div class="box-footer">
                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
              </div>
                
              </div>

</form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      
      
    </div>
  </div>

</div>



<!--add new end-->




























<?php include('footer.php');?>